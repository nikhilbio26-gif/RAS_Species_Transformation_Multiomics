# ============================================================
# 07_fig5_erk.R  -  Figure 5: ERK1/ERK2 activation-loop phosphorylation, mouse and human
# ============================================================
# ERK1 (MAPK3) and ERK2 (MAPK1) are activated by dual phosphorylation of the T-E-Y motif in
# the activation loop. The sites are found from the flanking sequence (not from residue
# numbers, which differ between species and isoforms): the Thr or Tyr of a "TEY" tripeptide
# on MAPK1 / MAPK3. Bars show mean normalised log2 intensity (+/- SD) at 0, 30, 180 min with
# individual replicates; labels give log2FC vs untreated and the limma FDR.
#
# Input : results/01_loaded.rds, results/02_diff.rds
# Output: figures/Figure5_ERK_activation_loop.*, results/ERK_activation_loop_sites.csv

source("scripts/00_config.R")
loaded <- readRDS(file.path(res_dir, "01_loaded.rds")); mouse <- loaded$mouse; human <- loaded$human
d2 <- readRDS(file.path(res_dir, "02_diff.rds"))
list2env(d2[c("tt_M_TPA30", "tt_M_TPA180", "tt_H_TPA30", "tt_H_TPA180")], environment())

# 15-mer flank, site at position 8: Tyr of TEY = positions 6-8 ; Thr of TEY = positions 8-10
is_tey <- function(aa, flank) (aa == "Y" & substr(toupper(flank), 6, 8) == "TEY") |
                              (aa == "T" & substr(toupper(flank), 8, 10) == "TEY")
has_gene <- function(g, sym) grepl(paste0("(^|;)", sym, "(;|$)"), toupper(g))

erk_sites <- function(sites) sites %>%
  dplyr::filter(is_tey(aa, flank_clean), has_gene(gene, "MAPK1") | has_gene(gene, "MAPK3")) %>%
  dplyr::mutate(kinase = ifelse(has_gene(gene, "MAPK3"), "ERK1", "ERK2"),
                site_lab = paste0(kinase, " ", aa, loc))

build <- function(norm, meta, sites, cl, species, tt30, tt180) {
  es <- erk_sites(sites)
  if (nrow(es) == 0) { cat("  [warn] no ERK activation-loop sites found in", species, "\n"); return(NULL) }
  m <- dplyr::filter(meta, cell_line == cl)
  long <- norm[es$CollapseKey, m$label, drop = FALSE] %>% as.data.frame() %>%
    tibble::rownames_to_column("CollapseKey") %>%
    tidyr::pivot_longer(-CollapseKey, names_to = "label", values_to = "log2int") %>%
    dplyr::left_join(m, by = "label") %>% dplyr::left_join(es, by = "CollapseKey") %>%
    dplyr::mutate(species = species, condition = factor(condition, cond_levels))
  stat <- dplyr::bind_rows(
    tt30  %>% dplyr::filter(CollapseKey %in% es$CollapseKey) %>% dplyr::transmute(CollapseKey, condition = "TPA30",  logFC, fdr = adj.P.Val),
    tt180 %>% dplyr::filter(CollapseKey %in% es$CollapseKey) %>% dplyr::transmute(CollapseKey, condition = "TPA180", logFC, fdr = adj.P.Val)) %>%
    dplyr::mutate(condition = factor(condition, cond_levels))
  list(long = long, stat = stat, sites = es)
}
mm <- build(mouse$norm, mouse$meta, mouse$sites, "M", "Mouse", tt_M_TPA30, tt_M_TPA180)
hh <- build(human$norm, human$meta, human$sites, "H", "Human", tt_H_TPA30, tt_H_TPA180)
parts <- Filter(Negate(is.null), list(mm, hh))
if (length(parts) == 0) stop("No ERK1/2 activation-loop (TEY) sites found.", call. = FALSE)

long <- dplyr::bind_rows(lapply(parts, `[[`, "long")) %>%
  dplyr::mutate(species = factor(species, c("Mouse", "Human")))
stat <- dplyr::bind_rows(lapply(seq_along(parts), function(i) {
  s <- parts[[i]]$stat; s$species <- as.character(parts[[i]]$long$species[1]); s %>%
    dplyr::left_join(parts[[i]]$sites %>% dplyr::select(CollapseKey, site_lab), by = "CollapseKey")
})) %>% dplyr::mutate(species = factor(species, c("Mouse", "Human")))

summ <- long %>% dplyr::group_by(species, site_lab, condition) %>%
  dplyr::summarise(mean = mean(log2int, na.rm = TRUE), sd = sd(log2int, na.rm = TRUE), .groups = "drop") %>%
  dplyr::left_join(stat, by = c("species", "site_lab", "condition")) %>%
  dplyr::mutate(stars = dplyr::case_when(is.na(fdr) ~ "", fdr < 0.001 ~ "***", fdr < 0.01 ~ "**", fdr < 0.05 ~ "*", TRUE ~ "ns"),
                lab = ifelse(is.na(logFC), "", sprintf("%+.2f\n%s", logFC, stars)))

readr::write_csv(summ %>% dplyr::select(species, site = site_lab, condition, mean_log2_intensity = mean,
                                       sd = sd, log2FC_vs_untreated = logFC, FDR = fdr),
                 file.path(res_dir, "ERK_activation_loop_sites.csv"))
print(as.data.frame(summ %>% dplyr::filter(condition != "untreated") %>%
                      dplyr::select(species, site_lab, condition, logFC, fdr)), digits = 3)

cat("\nCompare with the manuscript text (log2FC at 30 min, FDR < 0.01 for all four):\n")
chk <- function(sp, kin) {
  v <- summ$logFC[summ$species == sp & grepl(paste0(kin, " Y"), summ$site_lab) & summ$condition == "TPA30"]
  if (length(v) == 1) v else NA_real_
}
check("mouse ERK1 / ERK2 Tyr, 30 min", c(chk("Mouse", "ERK1"), chk("Mouse", "ERK2")), c(1.64, 1.69), tol = 0.02)
check("human ERK1 / ERK2 Tyr, 30 min", c(chk("Human", "ERK1"), chk("Human", "ERK2")), c(2.60, 2.59), tol = 0.02)

time_lab <- c(untreated = "0", TPA30 = "30", TPA180 = "180")
p <- ggplot(summ, aes(condition, mean, fill = condition)) +
  geom_col(width = 0.7, colour = "black", linewidth = 0.3) +
  geom_errorbar(aes(ymin = mean - sd, ymax = mean + sd), width = 0.18, linewidth = 0.3) +
  geom_point(data = long, aes(condition, log2int), inherit.aes = FALSE, shape = 21, fill = "white",
             size = 1.1, stroke = 0.3, position = position_jitter(width = 0.08, height = 0, seed = 1)) +
  geom_text(aes(y = mean + sd, label = lab), vjust = -0.3, size = 2.4, lineheight = 0.85, family = font_family) +
  facet_grid(species ~ site_lab, scales = "free_y") +
  scale_fill_manual(values = cond_colors, guide = "none") +
  scale_x_discrete(labels = time_lab) +
  scale_y_continuous(expand = expansion(mult = c(0, 0.25))) +
  labs(title = "Fig. 5  ERK1/2 activation-loop phosphorylation after TPA",
       subtitle = "Bars: mean +/- SD of normalised log2 intensity; labels: log2FC vs untreated and limma FDR (*** <0.001, ** <0.01, * <0.05)",
       x = "Minutes after TPA", y = "log2 intensity (median-normalised)") +
  theme_pub + theme(plot.subtitle = element_text(size = base_size - 1))
save_both(p, "Figure5_ERK_activation_loop", w = 5.2, h = 4.2)
