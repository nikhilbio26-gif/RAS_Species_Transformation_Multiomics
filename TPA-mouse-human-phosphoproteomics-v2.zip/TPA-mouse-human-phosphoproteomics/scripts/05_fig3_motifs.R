# ============================================================
# 05_fig3_motifs.R  -  Figure 3: kinase-motif composition of TPA-up-regulated sites
# ============================================================
# motif-x (rmotifx) is run on the S/T phosphosites that are significantly UP after TPA
# (|log2FC| >= 1, FDR < 0.05), separately for mouse and human and for 30 and 180 min.
# Background = all S/T phosphosites of that species in the filtered dataset.
# motif-x is iterative/greedy: the sites matched by successive motifs are disjoint, so the
# per-motif counts (fg.matches) can be summed within a motif family.
#
# Families (from the motif string):
#   Proline-directed (ERK/MAPK/CDK-like): [S/T]-P  or  P at -2
#   Basophilic (PKC/RSK/AKT-like)       : R/K at -3, -2 or -5 positions
#   Other
#
# Fig 3   pie charts of motif-family composition at 180 min (mouse vs human)
# Fig 3b  same at 30 min (supplement)
# Fig 3c  motif-x fold enrichment of each motif (dot plot)
# Extra   raw fraction of up-regulated S/T sites with Pro at +1, mouse vs human
#
# Input : results/01_loaded.rds, results/02_diff.rds   (needs the rmotifx package)
# Output: figures/Figure3_*, results/motifx_results.csv, results/motif_family_counts.csv,
#         results/proline_fraction_test.csv

source("scripts/00_config.R")
if (!requireNamespace("rmotifx", quietly = TRUE)) stop("Install rmotifx: install.packages('rmotifx')", call. = FALSE)
loaded <- readRDS(file.path(res_dir, "01_loaded.rds")); mouse <- loaded$mouse; human <- loaded$human
d2 <- readRDS(file.path(res_dir, "02_diff.rds"))
list2env(d2[c("tt_M_TPA30", "tt_M_TPA180", "tt_H_TPA30", "tt_H_TPA180")], environment())

up_flanks <- function(tt, sites) {
  tt %>% dplyr::filter(sig == "up") %>% dplyr::left_join(sites, by = "CollapseKey") %>%
    dplyr::filter(aa %in% c("S", "T")) %>% dplyr::pull(flank_clean) %>% toupper() %>% unique()
}
run_motifx <- function(tt, sites, species, time, min_seqs = 10, pval_cutoff = 1e-4) {
  fg <- up_flanks(tt, sites)
  bg <- sites %>% dplyr::filter(aa %in% c("S", "T")) %>% dplyr::pull(flank_clean) %>% toupper() %>% unique()
  cat(sprintf("  %-5s %-7s %d up-regulated S/T sites\n", species, time, length(fg)))
  mx <- rmotifx::motifx(fg, bg, central.res = "ST", min.seqs = min_seqs, pval.cutoff = pval_cutoff)
  if (is.null(mx) || nrow(mx) == 0) return(NULL)
  mx$species <- species; mx$time <- time; mx$n_up_sites <- length(fg)
  mx
}

cat("motif-x on TPA-up-regulated S/T sites\n")
motifs <- dplyr::bind_rows(
  run_motifx(tt_M_TPA30,  mouse$sites, "Mouse", "30 min"),
  run_motifx(tt_M_TPA180, mouse$sites, "Mouse", "180 min"),
  run_motifx(tt_H_TPA30,  human$sites, "Human", "30 min"),
  run_motifx(tt_H_TPA180, human$sites, "Human", "180 min"))
if (is.null(motifs) || nrow(motifs) == 0) stop("motif-x returned no motifs.", call. = FALSE)

classify_motif <- function(m) dplyr::case_when(
  stringr::str_detect(m, "\\[ST\\]P") | stringr::str_detect(m, "P.\\[ST\\]") ~ "Proline-directed (ERK/MAPK)",
  stringr::str_detect(m, "R.\\[ST\\]") | stringr::str_detect(m, "K..\\[ST\\]") |
    stringr::str_detect(m, "R..\\[ST\\]") | stringr::str_detect(m, "RK.\\[ST\\]") ~ "Basophilic (PKC/RSK)",
  TRUE ~ "Other")
fam_levels <- c("Basophilic (PKC/RSK)", "Proline-directed (ERK/MAPK)", "Other")
fam_colors <- c("Basophilic (PKC/RSK)" = "#0072B2", "Proline-directed (ERK/MAPK)" = "#D55E00", "Other" = "#999999")

motifs <- motifs %>% dplyr::mutate(family = factor(classify_motif(motif), fam_levels),
                                   species = factor(species, c("Mouse", "Human")),
                                   time = factor(time, c("30 min", "180 min")))
readr::write_csv(motifs, file.path(res_dir, "motifx_results.csv"))

fam_counts <- motifs %>% dplyr::group_by(time, species, family) %>%
  dplyr::summarise(n_sites = sum(fg.matches), n_motifs = dplyr::n(), .groups = "drop") %>%
  tidyr::complete(time, species, family, fill = list(n_sites = 0, n_motifs = 0)) %>%
  dplyr::group_by(time, species) %>%
  dplyr::mutate(total = sum(n_sites), percent = round(100 * n_sites / total, 1)) %>% dplyr::ungroup()
readr::write_csv(fam_counts, file.path(res_dir, "motif_family_counts.csv"))
print(as.data.frame(fam_counts))

get_n <- function(tm, sp, fam) fam_counts$n_sites[fam_counts$time == tm & fam_counts$species == sp & fam_counts$family == fam]
cat("\nCompare with the manuscript pie charts (180 min):\n")
check("Human basophilic / proline / other", c(get_n("180 min", "Human", fam_levels[1]), get_n("180 min", "Human", fam_levels[2]),
                                              get_n("180 min", "Human", fam_levels[3])), c(905, 756, 274))
check("Mouse basophilic / proline / other", c(get_n("180 min", "Mouse", fam_levels[1]), get_n("180 min", "Mouse", fam_levels[2]),
                                              get_n("180 min", "Mouse", fam_levels[3])), c(599, 968, 177))

# ---- pie charts -----------------------------------------------------------------------------
make_pie <- function(tm, title, name) {
  df <- fam_counts %>% dplyr::filter(time == tm, n_sites > 0) %>%
    dplyr::mutate(lab = sprintf("%d\n(%.0f%%)", n_sites, percent),
                  strip = sprintf("%s (n = %d sites)", species, total),
                  strip = factor(strip, unique(strip[order(species)])))   # Mouse first
  p <- ggplot(df, aes(x = "", y = n_sites, fill = family)) +
    geom_col(width = 1, colour = "white", linewidth = 0.4) +
    geom_text(aes(label = lab), position = position_stack(vjust = 0.5), size = 2.6,
              family = font_family, colour = "white", lineheight = 0.9) +
    coord_polar(theta = "y") + facet_wrap(~strip) +
    scale_fill_manual(values = fam_colors, name = "Motif family") +
    labs(title = title) +
    theme_void(base_size = base_size, base_family = font_family) +
    theme(plot.title = element_text(face = "bold", size = base_size + 1),
          strip.text = element_text(face = "bold", size = base_size, margin = margin(b = 3)),
          legend.position = "bottom", legend.key.size = unit(0.35, "cm"))
  save_both(p, name, w = 4.6, h = 3.1)
}
make_pie("180 min", "Fig. 3  Motif families among TPA-up-regulated sites, 180 min", "Figure3_motif_pies_180min")
make_pie("30 min",  "Fig. 3b  Motif families among TPA-up-regulated sites, 30 min", "Figure3b_motif_pies_30min")

# ---- motif-x dot plot (supplement) ------------------------------------------------------------
dot <- motifs %>% dplyr::mutate(motif_lab = stringr::str_replace_all(motif, "\\.", "·"))
dot$motif_lab <- factor(dot$motif_lab, levels = dot %>% dplyr::group_by(motif_lab) %>%
                          dplyr::summarise(b = max(fold.increase), .groups = "drop") %>%
                          dplyr::arrange(b) %>% dplyr::pull(motif_lab))
pd <- ggplot(dot, aes(time, motif_lab)) +
  geom_point(aes(size = fold.increase, fill = family), shape = 21, colour = "black", stroke = 0.3) +
  facet_grid(~species) +
  scale_size_continuous(name = "Fold\nenrichment", range = c(1, 5)) +
  scale_fill_manual(values = fam_colors, name = "Family") +
  guides(fill = guide_legend(override.aes = list(size = 3))) +
  labs(title = "Fig. 3c  motif-x motifs", x = NULL, y = NULL) +
  theme_pub + theme(axis.text.y = element_text(size = base_size - 1))
save_both(pd, "Figure3c_motifx_dotplot", w = 5, h = max(3, 0.16 * nlevels(dot$motif_lab) + 1.5))

# ---- raw proline-directed fraction (independent of motif-x background normalisation) -------------
pro_frac <- function(tt, sites, species, time) {
  f <- up_flanks(tt, sites)
  tibble::tibble(species = species, time = time, n_up = length(f), n_pro = sum(substr(f, 9, 9) == "P"))
}
pf <- dplyr::bind_rows(pro_frac(tt_M_TPA30, mouse$sites, "Mouse", "30 min"), pro_frac(tt_H_TPA30, human$sites, "Human", "30 min"),
                       pro_frac(tt_M_TPA180, mouse$sites, "Mouse", "180 min"), pro_frac(tt_H_TPA180, human$sites, "Human", "180 min")) %>%
  dplyr::mutate(fraction = n_pro / n_up)
tests <- dplyr::bind_rows(lapply(c("30 min", "180 min"), function(tm) {
  m <- pf[pf$time == tm & pf$species == "Mouse", ]; h <- pf[pf$time == tm & pf$species == "Human", ]
  tibble::tibble(time = tm, mouse_fraction = m$fraction, human_fraction = h$fraction,
                 p_chisq_uncorrected = prop.test(c(m$n_pro, h$n_pro), c(m$n_up, h$n_up), correct = FALSE)$p.value,
                 p_chisq_yates       = prop.test(c(m$n_pro, h$n_pro), c(m$n_up, h$n_up), correct = TRUE)$p.value)
}))
print(as.data.frame(tests))
readr::write_csv(tests, file.path(res_dir, "proline_fraction_test.csv"))
cat("Manuscript draft: 38.3% vs 35.1% (P = 0.051) at 30 min; 41.5% vs 38.6% (P = 0.044) at 180 min.\n",
    "Fractions are independent of the test; compare which p-value column matches the draft.\n")
