# ============================================================
# 01_load_and_normalise.R
# Spectronaut PTM reports -> filtered, log2, median-normalised matrices
# ============================================================
# Input : data/TPA_Mouse_Phospho_Report.tsv, data/TPA_Human_Phospho_Report.csv
#         metadata/sample_metadata_{mouse,human}.csv
# Output: results/01_loaded.rds  (list: mouse, human; each with norm, meta, sites)
#
# Steps per species
#   1. read all columns as text; keep the 10 PTM annotation columns + the sample columns
#   2. convert intensities (European decimal commas); "Filtered" / blank / 0 -> NA
#   3. keep Phospho (STY) rows with at least one quantified value
#   4. keep sites quantified in >= 2 of 3 replicates in at least one line x condition group
#   5. log2, then median-normalise ALL samples of that species to a common global median
#      (all lines are normalised together, e.g. M + MR in mouse; H + HR + HT in human)

source("scripts/00_config.R")

load_species <- function(path, delim, meta_file) {
  stopifnot(file.exists(path), file.exists(meta_file))
  meta <- readr::read_csv(meta_file, show_col_types = FALSE)

  raw <- as.data.frame(readr::read_delim(path, delim = delim,
                                         col_types = readr::cols(.default = "c"), progress = FALSE))
  missing_cols <- setdiff(meta$column, names(raw))
  if (length(missing_cols))
    stop("Columns listed in ", meta_file, " were not found in ", path, ":\n  ",
         paste(missing_cols, collapse = "\n  "), call. = FALSE)

  raw <- dplyr::select(raw, dplyr::all_of(names(raw)[1:10]), dplyr::all_of(meta$column))
  dat <- raw %>% dplyr::mutate(dplyr::across(dplyr::all_of(meta$column), to_num)) %>%
    dplyr::filter(PTM.ModificationTitle == "Phospho (STY)")
  dat <- dat[rowSums(!is.na(dat[meta$column])) > 0, ]

  grp   <- split(meta$column, paste(meta$cell_line, meta$condition, sep = "_"))
  valid <- sapply(grp, function(cs) rowSums(!is.na(dat[cs])))
  dat   <- dat[apply(valid, 1, function(v) any(v >= 2)), ]

  lab <- paste(meta$cell_line, meta$condition, paste0("r", meta$replicate), sep = "_")
  mat <- as.matrix(dat[, meta$column]); rownames(mat) <- dat$PTM.CollapseKey; colnames(mat) <- lab
  meta$label <- lab

  lg   <- log2(mat)
  norm <- sweep(lg, 2, colMedians(lg, na.rm = TRUE) - median(lg, na.rm = TRUE), "-")

  sites <- dat %>% dplyr::transmute(
    CollapseKey = PTM.CollapseKey, gene = PG.Genes, aa = PTM.SiteAA,
    loc = as.numeric(PTM.SiteLocation),
    flank_clean = stringr::str_replace_all(PTM.FlankingRegion, "_", "X"),
    label = paste0(PG.Genes, "_", PTM.SiteAA, PTM.SiteLocation))

  cat(sprintf("  %d phosphosites | %d samples | S/T/Y = %s\n", nrow(norm), ncol(norm),
              paste(table(factor(sites$aa, c("S", "T", "Y"))), collapse = "/")))
  list(norm = norm, meta = meta, sites = sites)
}

cat("Mouse:\n"); mouse <- load_species(mouse_report, "\t", mouse_meta_file)
cat("Human:\n"); human <- load_species(human_report, ";",  human_meta_file)

saveRDS(list(mouse = mouse, human = human), file.path(res_dir, "01_loaded.rds"))
cat("Saved results/01_loaded.rds\n")
