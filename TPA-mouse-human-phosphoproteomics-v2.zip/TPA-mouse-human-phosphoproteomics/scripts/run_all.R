# ============================================================
# run_all.R - runs the whole pipeline in order
# ============================================================
# From the repository root:   Rscript scripts/run_all.R
# Each step runs in tryCatch, so one failing figure does not stop the others;
# a summary of OK / FAILED steps is printed at the end.

steps <- c("01_load_and_normalise.R", "02_differential_and_orthologs.R", "03_fig1_pca.R",
           "04_fig2_concordance.R", "05_fig3_motifs.R", "06_fig4_top20_30min.R",
           "07_fig5_erk.R", "08_fig6_hallmark_orthologous_sites.R")
status <- setNames(rep("not run", length(steps)), steps)
for (s in steps) {
  cat("\n================ ", s, " ================\n")
  res <- tryCatch({ source(file.path("scripts", s), local = new.env()); "OK" },
                  error = function(e) paste("FAILED:", conditionMessage(e)))
  status[s] <- res
  cat(res, "\n")
}
dir.create(file.path(Sys.getenv("TPA_OUT_DIR","."),"results"),showWarnings=FALSE,recursive=TRUE)
writeLines(capture.output(sessionInfo()), file.path(Sys.getenv("TPA_OUT_DIR","."),"results","sessionInfo.txt"))
cat("\n================ SUMMARY ================\n")
for (s in steps) cat(sprintf("%-45s %s\n", s, status[s]))
if (any(grepl("^FAILED", status))) quit(status = 1)
