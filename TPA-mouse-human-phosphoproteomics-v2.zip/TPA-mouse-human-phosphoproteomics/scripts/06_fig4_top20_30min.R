# ============================================================
# 06_fig4_top20_30min.R  -  Figure 4: top 20 concordantly up / down sites at 30 min
# ============================================================
# Among the orthologous sites with complete data (the PCA set), keep sites that are
# significant in the SAME direction in both species at 30 min
# (|log2FC| >= 1 and FDR < 0.05 in mouse AND in human), rank by combined magnitude
# (sum of the two log2FC values), and show the top 20 up (Fig. 4a) and top 20 down (Fig. 4b).
# Heatmap values are intensities z-scored WITHIN species (rows), so mouse and human
# columns are comparable in pattern, not in absolute level.
#
# Input : results/01_loaded.rds, results/02_diff.rds, results/03_pca.rds
# Output: figures/Figure4a_top20_up_30min.*, Figure4b_top20_down_30min.*,
#         results/top20_concordant_30min.csv

source("scripts/00_config.R")
loaded <- readRDS(file.path(res_dir, "01_loaded.rds")); mouse <- loaded$mouse; human <- loaded$human
d2 <- readRDS(file.path(res_dir, "02_diff.rds"))
list2env(d2[c("tt_M_TPA30", "tt_H_TPA30", "keys_kept")], environment())
joint_mat <- readRDS(file.path(res_dir, "03_pca.rds"))$joint_mat      # sites x 18 samples, z-scored within species

lab_m <- setNames(mouse$sites$label, mouse$sites$CollapseKey)
lab_h <- setNames(human$sites$label, human$sites$CollapseKey)

conc <- keys_kept %>%
  dplyr::mutate(row = dplyr::row_number()) %>%
  dplyr::left_join(tt_M_TPA30 %>% dplyr::select(CollapseKey, m_fc = logFC, m_q = adj.P.Val), by = "CollapseKey") %>%
  dplyr::left_join(tt_H_TPA30 %>% dplyr::select(CollapseKey_h = CollapseKey, h_fc = logFC, h_q = adj.P.Val), by = "CollapseKey_h") %>%
  dplyr::mutate(sig_both = m_q < fdr_cutoff & h_q < fdr_cutoff,
                direction = dplyr::case_when(sig_both & m_fc >=  fc_cutoff & h_fc >=  fc_cutoff ~ "up",
                                             sig_both & m_fc <= -fc_cutoff & h_fc <= -fc_cutoff ~ "down",
                                             TRUE ~ "none"),
                combined = m_fc + h_fc,
                site = paste0(lab_h[CollapseKey_h], " / ", lab_m[CollapseKey]))
cat(sprintf("Complete-data orthologous sites: %d | concordantly up at 30 min: %d | concordantly down: %d\n",
            nrow(conc), sum(conc$direction == "up", na.rm = TRUE), sum(conc$direction == "down", na.rm = TRUE)))

top20 <- dplyr::bind_rows(
  conc %>% dplyr::filter(direction == "up")   %>% dplyr::slice_max(combined,  n = 20, with_ties = FALSE),
  conc %>% dplyr::filter(direction == "down") %>% dplyr::slice_min(combined, n = 20, with_ties = FALSE))
readr::write_csv(top20 %>% dplyr::select(direction, site, m_fc, m_q, h_fc, h_q, combined),
                 file.path(res_dir, "top20_concordant_30min.csv"))

ann_col <- data.frame(Species = factor(ifelse(colnames(joint_mat) %in% mouse$meta$label, "Mouse", "Human"), c("Mouse", "Human")),
                      Condition = factor(c(mouse$meta$condition, human$meta$condition)[match(
                        colnames(joint_mat), c(mouse$meta$label, human$meta$label))], cond_levels),
                      row.names = colnames(joint_mat))
ann_colors <- list(Species = c(Mouse = unname(species_colors["Mouse"]), Human = unname(species_colors["Human"])),
                   Condition = cond_colors)

draw_top <- function(dir, title, name) {
  tp <- top20 %>% dplyr::filter(direction == dir)
  if (nrow(tp) < 2) { cat("  [skip]", name, "- fewer than 2 concordant sites\n"); return(invisible(NULL)) }
  mat <- joint_mat[tp$row, , drop = FALSE]; rownames(mat) <- make.unique(tp$site)
  # order columns: mouse (0, 30, 180) then human (0, 30, 180)
  ph <- pheatmap::pheatmap(mat, cluster_rows = FALSE, cluster_cols = FALSE, annotation_col = ann_col,
                           annotation_colors = ann_colors, show_colnames = FALSE, gaps_col = ncol(mat) / 2,
                           color = colorRampPalette(c("#2166ac", "white", "#d6604d"))(101),
                           breaks = seq(-2.5, 2.5, length.out = 102), fontsize = 8, fontsize_row = 7,
                           main = title, silent = TRUE)
  save_pheatmap(ph, name, w = 6.2, h = 0.17 * nrow(mat) + 2.2)
  cat(sprintf("  %s: %d sites (mouse log2FC %.1f to %.1f; human %.1f to %.1f)\n", name, nrow(tp),
              min(tp$m_fc), max(tp$m_fc), min(tp$h_fc), max(tp$h_fc)))
}
draw_top("up",   "Fig. 4a  Top 20 concordantly up-regulated sites, 30 min", "Figure4a_top20_up_30min")
draw_top("down", "Fig. 4b  Top 20 concordantly down-regulated sites, 30 min", "Figure4b_top20_down_30min")
