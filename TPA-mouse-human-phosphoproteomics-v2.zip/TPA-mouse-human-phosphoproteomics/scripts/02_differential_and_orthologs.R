# ============================================================
# 02_differential_and_orthologs.R
# limma TPA responses (parental lines) + 1:1 orthologous phosphosite pairs
# ============================================================
# Input : results/01_loaded.rds
# Output: results/02_diff.rds
#         results/TPA_{M,H}_{30,180}min_vs_untreated.csv   (full limma tables)
#         results/TPA_response_counts.csv                  (significant up/down per contrast)
#         results/ortholog_site_pairs.csv                  (all 1:1 pairs, with completeness flag)
#
# Differential analysis (per species, parental line only: M in mouse, H in human)
#   model ~ 0 + condition; contrasts TPA30 - untreated and TPA180 - untreated
#   sites need >= 2 valid values in at least 2 of the 3 conditions
#   eBayes(trend = TRUE, robust = TRUE); significant = |log2FC| >= 1 and BH-FDR < 0.05
#
# Orthologous sites
#   genes: 1:1 mouse-human orthologs only (babelgene; many-to-many mappings dropped)
#   sites: same human gene + same residue + identical 15-mer flanking sequence
#   pairs are de-duplicated on BOTH keys (one mouse site <-> one human site)

source("scripts/00_config.R")
loaded <- readRDS(file.path(res_dir, "01_loaded.rds"))
mouse <- loaded$mouse; human <- loaded$human

run_tpa <- function(norm, meta, cl, sites) {
  lab_of <- setNames(sites$label, sites$CollapseKey)
  m   <- dplyr::filter(meta, cell_line == cl)
  mat <- norm[, m$label, drop = FALSE]
  g   <- factor(m$condition, levels = cond_levels)
  v   <- sapply(levels(g), function(x) rowSums(!is.na(mat[, g == x, drop = FALSE])))
  mat <- mat[rowSums(v >= 2) >= 2, ]
  d   <- model.matrix(~0 + g); colnames(d) <- levels(g)
  fit <- eBayes(contrasts.fit(lmFit(mat, d),
                              makeContrasts(T30 = TPA30 - untreated, T180 = TPA180 - untreated, levels = d)),
                trend = TRUE, robust = TRUE)
  get <- function(co) topTable(fit, coef = co, number = Inf, sort.by = "none") %>%
    tibble::rownames_to_column("CollapseKey") %>%
    dplyr::mutate(label = lab_of[CollapseKey],
                  sig = dplyr::case_when(adj.P.Val < fdr_cutoff & logFC >=  fc_cutoff ~ "up",
                                         adj.P.Val < fdr_cutoff & logFC <= -fc_cutoff ~ "down",
                                         TRUE ~ "ns"))
  list(t30 = get("T30"), t180 = get("T180"))
}

cat("limma: mouse (M) and human (H) TPA responses...\n")
mt <- suppressWarnings(run_tpa(mouse$norm, mouse$meta, "M", mouse$sites))   # "partial NA coefficients" is expected
ht <- suppressWarnings(run_tpa(human$norm, human$meta, "H", human$sites))
tt_M_TPA30 <- mt$t30; tt_M_TPA180 <- mt$t180
tt_H_TPA30 <- ht$t30; tt_H_TPA180 <- ht$t180

for (nm in c("M_TPA30", "M_TPA180", "H_TPA30", "H_TPA180")) {
  tt <- get(paste0("tt_", nm))
  readr::write_csv(tt, file.path(res_dir, sprintf("TPA_%s_%smin_vs_untreated.csv", substr(nm, 1, 1), sub(".*TPA", "", nm))))
}

counts <- tibble::tibble(
  species  = rep(c("Mouse", "Human"), each = 2),
  timepoint = rep(c("30 min", "180 min"), 2),
  up   = c(sum(tt_M_TPA30$sig == "up"),   sum(tt_M_TPA180$sig == "up"),
           sum(tt_H_TPA30$sig == "up"),   sum(tt_H_TPA180$sig == "up")),
  down = c(sum(tt_M_TPA30$sig == "down"), sum(tt_M_TPA180$sig == "down"),
           sum(tt_H_TPA30$sig == "down"), sum(tt_H_TPA180$sig == "down")))
readr::write_csv(counts, file.path(res_dir, "TPA_response_counts.csv"))
print(counts)

cat("\nCheck against the manuscript drafts:\n")
check("mouse 30 min up / down",  c(counts$up[1], counts$down[1]), c(1589, 955))
check("mouse 180 min up / down", c(counts$up[2], counts$down[2]), c(2585, 3176))
check("human 30 min up / down",  c(counts$up[3], counts$down[3]), c(2170, 1555))
check("human 180 min up / down", c(counts$up[4], counts$down[4]), c(2419, 1912))

# ---- orthologous site pairs ---------------------------------------------------------
cat("\nMatching 1:1 orthologous phosphosites...\n")
orth <- babelgene::orthologs(genes = unique(stats::na.omit(mouse$sites$gene)), species = "mouse", human = FALSE) %>%
  dplyr::transmute(mouse_gene = symbol, human_gene = human_symbol) %>% dplyr::distinct()
orth_1to1 <- orth %>% dplyr::filter(!is.na(mouse_gene), !is.na(human_gene)) %>%
  dplyr::add_count(mouse_gene, name = "n_h") %>% dplyr::add_count(human_gene, name = "n_m") %>%
  dplyr::filter(n_h == 1, n_m == 1) %>% dplyr::select(mouse_gene, human_gene)

pairs <- dplyr::inner_join(
  mouse$sites %>% dplyr::filter(!is.na(gene)) %>%
    dplyr::inner_join(orth_1to1, by = c("gene" = "mouse_gene")) %>%
    dplyr::transmute(CollapseKey, human_gene, aa, flank7 = toupper(flank_clean)),
  human$sites %>% dplyr::transmute(CollapseKey_h = CollapseKey, human_gene = gene, aa,
                                   flank7 = toupper(flank_clean)),
  by = c("human_gene", "aa", "flank7"), relationship = "many-to-many") %>%
  dplyr::distinct(CollapseKey, .keep_all = TRUE) %>%
  dplyr::distinct(CollapseKey_h, .keep_all = TRUE) %>%
  dplyr::filter(CollapseKey %in% rownames(mouse$norm), CollapseKey_h %in% rownames(human$norm))
cat("  ortholog site pairs (1:1, de-duplicated):", nrow(pairs), "\n")

# Pairs with complete data (no missing value) in all 9 parental samples of BOTH species.
# These are used for the PCA, the top-20 heatmaps and the Hallmark analysis.
m_cols <- mouse$meta$label[mouse$meta$cell_line == "M"]
h_cols <- human$meta$label[human$meta$cell_line == "H"]
mv <- mouse$norm[pairs$CollapseKey,   m_cols, drop = FALSE]
hv <- human$norm[pairs$CollapseKey_h, h_cols, drop = FALSE]
ok <- complete.cases(mv) & complete.cases(hv)
keys_kept <- pairs[ok, ]; mv <- mv[ok, , drop = FALSE]; hv <- hv[ok, , drop = FALSE]
cat("  pairs with complete data in all 18 parental samples:", nrow(keys_kept), "\n")
check("ortholog pairs (before completeness filter)", nrow(pairs), 5850)
check("ortholog sites with complete data", nrow(keys_kept), 2124)

readr::write_csv(dplyr::mutate(pairs, complete_both_species = ok), file.path(res_dir, "ortholog_site_pairs.csv"))
saveRDS(list(tt_M_TPA30 = tt_M_TPA30, tt_M_TPA180 = tt_M_TPA180,
             tt_H_TPA30 = tt_H_TPA30, tt_H_TPA180 = tt_H_TPA180,
             pairs = pairs, keys_kept = keys_kept, m_cols = m_cols, h_cols = h_cols,
             counts = counts),
        file.path(res_dir, "02_diff.rds"))
cat("Saved results/02_diff.rds\n")
