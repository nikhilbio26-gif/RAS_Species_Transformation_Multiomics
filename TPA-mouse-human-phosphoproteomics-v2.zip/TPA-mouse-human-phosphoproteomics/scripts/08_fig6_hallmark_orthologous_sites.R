# ============================================================
# 08_fig6_hallmark_orthologous_sites.R
# Figure 6: phosphorylation of MSigDB Hallmark target proteins (E2F, MYC, G2M) at orthologous sites
# ============================================================
# Question: do orthologous phosphosites on proteins belonging to a Hallmark gene set behave
# the same way in mouse and human over the time course?
#
# Site set: `hallmark_scope` in 00_config.R
#   "top500"        - the 500 orthologous sites of the combined PCA (Fig. 1b); default
#   "all_orthologs" - all orthologous sites with complete data in both species
# A site is assigned to a Hallmark when its (human) gene symbol is in that gene set.
# NOTE: these are phosphosites ON proteins whose genes are Hallmark members. They do not measure
#       the activity of E2F or MYC (those gene sets are defined by transcription).
#
# Per site and species: log2FC vs untreated at 30 and 180 min (limma). A site counts as
# "changed" when |log2FC| >= 1 and FDR < 0.05 in that species at that time.
#
# Fig 6a  mouse and human overlaid; trend line = mean log2FC of all sites; line thickness and
#         bubble size = number of changed sites; label = sites up / sites down
# Fig 6b  separate trends for up-changed and down-changed sites (bubble size and thickness =
#         number of sites) - use this when a set contains sites moving in both directions
# Fig 6c  every site as its own line (coloured by direction at 180 min), mouse and human panels
# Table   Hallmark_pattern_table.csv: for every Hallmark with >= 5 sites, how many sites are up
#         in both species at 30 min and what they do at 180 min; Fisher test vs the rest
#
# Input : results/01_loaded.rds, results/02_diff.rds, results/03_pca.rds
# Output: figures/Figure6*_*, results/Hallmark_pattern_table.csv, results/Hallmark_site_values.csv

source("scripts/00_config.R")
loaded <- readRDS(file.path(res_dir, "01_loaded.rds")); mouse <- loaded$mouse; human <- loaded$human
d2 <- readRDS(file.path(res_dir, "02_diff.rds"))
list2env(d2[c("tt_M_TPA30", "tt_M_TPA180", "tt_H_TPA30", "tt_H_TPA180", "keys_kept")], environment())
pca <- readRDS(file.path(res_dir, "03_pca.rds"))

lab_m <- setNames(mouse$sites$label, mouse$sites$CollapseKey)
lab_h <- setNames(human$sites$label, human$sites$CollapseKey)

# ---- site table: log2FC + FDR for the four contrasts -------------------------------------
base_sites <- if (hallmark_scope == "top500") keys_kept[pca$top500_idx, ] else keys_kept
cat(sprintf("Hallmark analysis on %d orthologous sites (scope: %s)\n", nrow(base_sites), hallmark_scope))
get <- function(tt, key, col) tt[[col]][match(key, tt$CollapseKey)]
state <- function(l, q) ifelse(!is.na(q) & q < fdr_cutoff & l >= fc_cutoff, "up",
                               ifelse(!is.na(q) & q < fdr_cutoff & l <= -fc_cutoff, "down", "ns"))
S <- tibble::tibble(
  gene = sub(";.*", "", base_sites$human_gene),
  id = base_sites$CollapseKey_h, human = lab_h[base_sites$CollapseKey_h], mouse = lab_m[base_sites$CollapseKey],
  M30  = get(tt_M_TPA30,  base_sites$CollapseKey,   "logFC"), qM30  = get(tt_M_TPA30,  base_sites$CollapseKey,   "adj.P.Val"),
  H30  = get(tt_H_TPA30,  base_sites$CollapseKey_h, "logFC"), qH30  = get(tt_H_TPA30,  base_sites$CollapseKey_h, "adj.P.Val"),
  M180 = get(tt_M_TPA180, base_sites$CollapseKey,   "logFC"), qM180 = get(tt_M_TPA180, base_sites$CollapseKey,   "adj.P.Val"),
  H180 = get(tt_H_TPA180, base_sites$CollapseKey_h, "logFC"), qH180 = get(tt_H_TPA180, base_sites$CollapseKey_h, "adj.P.Val")) %>%
  dplyr::mutate(sM30 = state(M30, qM30), sH30 = state(H30, qH30), sM180 = state(M180, qM180), sH180 = state(H180, qH180),
                pattern = dplyr::case_when(
                  sM30 == "up" & sH30 == "up" & sM180 == "up" & sH180 != "up" ~ "Both up at 30; 180: only mouse up",
                  sM30 == "up" & sH30 == "up" & sH180 == "up" & sM180 != "up" ~ "Both up at 30; 180: only human up",
                  sM30 == "up" & sH30 == "up" & sM180 != "up" & sH180 != "up" ~ "Both up at 30; neither up at 180",
                  sM30 == "up" & sH30 == "up" & sM180 == "up" & sH180 == "up" ~ "Up in both at both times",
                  sM30 == "down" & sH30 == "down"                              ~ "Both down at 30",
                  sM30 == "ns" & sH30 == "ns"                                  ~ "Neither significant at 30",
                  TRUE                                                         ~ "Other (one species at 30)"))
S <- S[!is.na(S$M30) & !is.na(S$H30) & !is.na(S$M180) & !is.na(S$H180), ]

hall <- load_hallmark()
S$hallmarks <- vapply(S$gene, function(g) paste(names(hall)[vapply(hall, function(x) g %in% x, NA)], collapse = "; "), "")

# ---- table over ALL Hallmarks --------------------------------------------------------------
up30 <- c("Both up at 30; 180: only mouse up", "Both up at 30; 180: only human up",
          "Both up at 30; neither up at 180", "Up in both at both times")
S$both30 <- S$pattern %in% up30
Sx <- S %>% dplyr::filter(hallmarks != "") %>% tidyr::separate_rows(hallmarks, sep = "; ") %>% dplyr::rename(hallmark = hallmarks)
Sx <- Sx[!duplicated(Sx[, c("hallmark", "gene", "M30", "H30", "M180", "H180")]), ]   # same-peptide duplicates count once
n_all <- nrow(S); n_both_all <- sum(S$both30)
tab <- Sx %>% dplyr::group_by(hallmark) %>%
  dplyr::summarise(n_sites = dplyr::n(), n_proteins = dplyr::n_distinct(gene), both_up30 = sum(both30),
                   only_mouse_180 = sum(pattern == "Both up at 30; 180: only mouse up"),
                   only_human_180 = sum(pattern == "Both up at 30; 180: only human up"),
                   neither_180 = sum(pattern == "Both up at 30; neither up at 180"),
                   both_at_180 = sum(pattern == "Up in both at both times"),
                   mean_M30 = mean(M30), mean_H30 = mean(H30), mean_M180 = mean(M180), mean_H180 = mean(H180), .groups = "drop") %>%
  dplyr::filter(n_sites >= 5)
if (nrow(tab) > 0) {
  tab$p_both30 <- mapply(function(k, n) fisher.test(matrix(c(k, n - k, n_both_all - k, (n_all - n) - (n_both_all - k)), 2),
                                                    alternative = "greater")$p.value, tab$both_up30, tab$n_sites)
  tab$FDR <- p.adjust(tab$p_both30, "BH")
  tab$obs_over_exp <- (tab$both_up30 / tab$n_sites) / (n_both_all / n_all)
  tab <- dplyr::arrange(tab, p_both30)
  readr::write_csv(tab, file.path(res_dir, "Hallmark_pattern_table.csv"))
  cat(sprintf("\n%d of %d sites are up in both species at 30 min. Top Hallmarks by over-representation:\n", n_both_all, n_all))
  print(as.data.frame(head(tab[, c("hallmark", "n_sites", "both_up30", "obs_over_exp", "p_both30", "FDR")], 8)), digits = 2)
}

# ---- long table for the selected Hallmarks --------------------------------------------------
L <- dplyr::bind_rows(lapply(hallmark_sets, function(h) {
  sub <- Sx[Sx$hallmark == h, ]
  if (nrow(sub) == 0) { cat("  [skip]", h, "- no sites in this scope\n"); return(NULL) }
  dplyr::bind_rows(
    tibble::tibble(hallmark = h, id = rep(sub$id, 2), site = rep(sub$human, 2), species = "Mouse", t = rep(1:2, each = nrow(sub)),
                   log2FC = c(sub$M30, sub$M180), state = c(sub$sM30, sub$sM180)),
    tibble::tibble(hallmark = h, id = rep(sub$id, 2), site = rep(sub$human, 2), species = "Human", t = rep(1:2, each = nrow(sub)),
                   log2FC = c(sub$H30, sub$H180), state = c(sub$sH30, sub$sH180)))
}))
if (is.null(L) || nrow(L) == 0) stop("None of hallmark_sets contain sites in this scope.", call. = FALSE)
n_h <- L %>% dplyr::distinct(hallmark, id) %>% dplyr::count(hallmark, name = "n")
L <- L %>% dplyr::left_join(n_h, by = "hallmark") %>%
  dplyr::mutate(panel = paste0(gsub("_", " ", hallmark), " (n=", n, " sites)"),
                panel = factor(panel, unique(panel)), species = factor(species, c("Mouse", "Human")))
readr::write_csv(L, file.path(res_dir, "Hallmark_site_values.csv"))
print(n_h)

zero <- dplyr::distinct(L, panel, id, site, species) %>% dplyr::mutate(t = 0, log2FC = 0, state = "ns")
siteL <- dplyr::bind_rows(L, zero)

summ <- L %>% dplyr::group_by(panel, species, t) %>%
  dplyr::summarise(m = mean(log2FC), n_up = sum(state == "up"), n_down = sum(state == "down"),
                   n_sig = n_up + n_down, .groups = "drop")
x_scale <- scale_x_continuous(breaks = 0:2, labels = c("0", "30", "180"), expand = expansion(mult = 0.15))

# ---- Fig 6a: mouse and human overlaid ----------------------------------------------------------
off  <- c(Mouse = -0.07, Human = 0.07)
spc  <- function(x) unname(off[as.character(x)])
summ5 <- summ %>% dplyr::mutate(xd = t + spc(species))
zero5 <- dplyr::distinct(summ5, panel, species) %>%
  dplyr::mutate(t = 0, xd = spc(species), m = 0, n_up = NA_integer_, n_down = NA_integer_, n_sig = NA_integer_)
pts5  <- dplyr::bind_rows(zero5, summ5) %>% dplyr::arrange(panel, species, t)
segs5 <- pts5 %>% dplyr::group_by(panel, species) %>%
  dplyr::mutate(x = dplyr::lag(xd), y = dplyr::lag(m), xend = xd, yend = m) %>% dplyr::ungroup() %>% dplyr::filter(!is.na(x))
site5 <- siteL %>% dplyr::mutate(xd = t + spc(species))

p6a <- ggplot() +
  geom_hline(yintercept = 0, colour = "grey60", linewidth = 0.3) +
  geom_line(data = site5, aes(xd, log2FC, group = interaction(id, species), colour = species), linewidth = 0.2, alpha = 0.25) +
  geom_segment(data = segs5, aes(x = x, xend = xend, y = y, yend = yend, colour = species, linewidth = n_sig),
               lineend = "round", alpha = 0.85) +
  geom_point(data = dplyr::filter(pts5, t > 0), aes(xd, m, size = n_sig, fill = species), shape = 21, colour = "black", stroke = 0.4) +
  geom_text(data = dplyr::filter(pts5, t > 0), aes(xd, m, label = paste0(n_up, "/", n_down), colour = species),
            vjust = -1.6, size = 2.2, family = font_family, show.legend = FALSE) +
  facet_wrap(~panel, nrow = 1) + x_scale +
  scale_colour_manual(values = species_colors, name = "Species") +
  scale_fill_manual(values = species_colors, name = "Species") +
  scale_size_area(max_size = 8, name = "Sites changed\n(|log2FC| >= 1,\nFDR < 0.05)") +
  scale_linewidth(range = c(0.4, 4.5)) + guides(linewidth = "none") +
  labs(x = "Minutes after TPA", y = "log2 fold change vs untreated",
       title = "Fig. 6a  Orthologous phosphosites on Hallmark target proteins: mouse vs human",
       subtitle = "Thick line = mean of all sites; thickness and bubble size = number of changed sites; label = sites up / sites down; faint lines = individual sites") +
  theme_pub + theme(plot.subtitle = element_text(size = base_size - 1))
save_both(p6a, "Figure6a_Hallmark_sites_overlay", w = 3.1 * length(unique(L$panel)) + 0.6, h = 3.4)

# ---- Fig 6b: separate up and down trends --------------------------------------------------------
dsum <- L %>% dplyr::filter(state %in% c("up", "down")) %>%
  dplyr::mutate(dir = ifelse(state == "up", "Up", "Down")) %>%
  dplyr::group_by(panel, species, dir, t) %>% dplyr::summarise(m = mean(log2FC), n = dplyr::n(), .groups = "drop")
dsum <- tidyr::expand_grid(dplyr::distinct(L, panel, species), dir = c("Up", "Down"), t = 1:2) %>%
  dplyr::left_join(dsum, by = c("panel", "species", "dir", "t")) %>% dplyr::mutate(n = tidyr::replace_na(n, 0))
segs6 <- dsum %>% dplyr::group_by(panel, species, dir) %>% dplyr::arrange(t) %>%
  dplyr::mutate(x = t - 1, xend = t, y = dplyr::lag(m, default = 0), yend = m) %>% dplyr::ungroup() %>%
  dplyr::filter(n > 0, !is.na(y), !is.na(yend))

p6b <- ggplot() +
  geom_hline(yintercept = 0, colour = "grey60", linewidth = 0.3) +
  geom_line(data = siteL, aes(t, log2FC, group = interaction(id, species)), colour = "grey85", linewidth = 0.2) +
  geom_segment(data = segs6, aes(x = x, xend = xend, y = y, yend = yend, linewidth = n, colour = dir), lineend = "round", alpha = 0.5) +
  geom_point(data = dplyr::filter(dsum, n > 0), aes(t, m, size = n, fill = dir), shape = 21, colour = "black", stroke = 0.4) +
  geom_text(data = dplyr::filter(dsum, n > 0), aes(t, m, label = n), nudge_x = 0.16, size = 2.4, family = font_family) +
  facet_grid(species ~ panel) + x_scale +
  scale_fill_manual(values = dir_colors, name = "Direction") + scale_colour_manual(values = dir_colors) +
  scale_size_area(max_size = 8, name = "No. of sites") + scale_linewidth(range = c(0.3, 4)) +
  guides(colour = "none", linewidth = "none") +
  labs(x = "Minutes after TPA", y = "log2 fold change vs untreated",
       title = "Fig. 6b  Up-changed and down-changed sites, trended separately",
       subtitle = "Number next to a bubble = sites significantly up (or down) in that species at that time") +
  theme_pub + theme(plot.subtitle = element_text(size = base_size - 1))
save_both(p6b, "Figure6b_Hallmark_sites_up_down", w = 3.1 * length(unique(L$panel)) + 0.6, h = 4.6)

# ---- Fig 6c: every site as its own line ------------------------------------------------------------
dir180 <- L %>% dplyr::filter(t == 2) %>%
  dplyr::mutate(dir180 = dplyr::case_when(log2FC >= 1 ~ "up", log2FC <= -1 ~ "down", TRUE ~ "flat")) %>%
  dplyr::select(panel, id, species, dir180)
sl <- dplyr::left_join(siteL, dir180, by = c("panel", "id", "species"))
p6c <- ggplot(sl, aes(t, log2FC, group = id, colour = dir180)) +
  geom_hline(yintercept = 0, colour = "grey60", linewidth = 0.3) +
  geom_line(linewidth = 0.4) + geom_point(size = 0.7) +
  ggrepel::geom_text_repel(data = dplyr::filter(sl, t == 2), aes(label = site), size = 1.9, family = font_family,
                           nudge_x = 0.35, direction = "y", segment.size = 0.15, min.segment.length = 0,
                           max.overlaps = Inf, show.legend = FALSE) +
  facet_grid(species ~ panel) +
  scale_x_continuous(breaks = 0:2, labels = c("0", "30", "180"), expand = expansion(mult = c(0.05, 0.6))) +
  scale_colour_manual(values = c(up = "#D55E00", down = "#0072B2", flat = "grey65"),
                      labels = c(up = ">= +1", down = "<= -1", flat = "between"), name = "log2FC at 180 min") +
  labs(x = "Minutes after TPA", y = "log2 fold change vs untreated",
       title = "Fig. 6c  Individual orthologous phosphosites on Hallmark target proteins") +
  theme_pub
save_both(p6c, "Figure6c_Hallmark_sites_individual", w = 3.4 * length(unique(L$panel)) + 0.6, h = 6)
cat("\nFigure 6 written to figures/\n")
