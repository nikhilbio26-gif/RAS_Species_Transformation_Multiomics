# ============================================================
# 00_config.R - shared settings, packages and helpers
# ============================================================
# Sourced by every other script. Run all scripts from the repository
# root (the folder that contains `scripts/`, `data/`, `metadata/`).
#
# Everything a user may want to change lives in this file.

if (!file.exists("scripts/00_config.R")) {
  stop("Run this script from the repository root (the folder containing scripts/), ",
       "e.g. setwd('path/to/TPA-mouse-human-phosphoproteomics').", call. = FALSE)
}

# ---- input / output locations -------------------------------------------------------
# Defaults: raw reports in data/, outputs in figures/ and results/. To redirect (e.g. for the
# synthetic-data test in tests/), set the environment variables TPA_DATA_DIR and TPA_OUT_DIR.
data_dir <- Sys.getenv("TPA_DATA_DIR", "data")
out_dir  <- Sys.getenv("TPA_OUT_DIR", ".")

mouse_report    <- file.path(data_dir, "TPA_Mouse_Phospho_Report.tsv")   # Spectronaut PTM report, tab-delimited
human_report    <- file.path(data_dir, "TPA_Human_Phospho_Report.csv")   # Spectronaut PTM report, semicolon-delimited
mouse_meta_file <- "metadata/sample_metadata_mouse.csv"
human_meta_file <- "metadata/sample_metadata_human.csv"

# Optional: Hallmark gene sets as a GMT file if msigdbr is unavailable
# (download "h.all.v*.Hs.symbols.gmt" from https://www.gsea-msigdb.org/ and put it in data/)
hallmark_gmt <- list.files(data_dir, pattern = "^h\\.all.*\\.symbols\\.gmt$", full.names = TRUE)

fig_dir <- file.path(out_dir, "figures")
res_dir <- file.path(out_dir, "results")
dir.create(fig_dir, showWarnings = FALSE, recursive = TRUE)
dir.create(res_dir, showWarnings = FALSE, recursive = TRUE)

# ---- analysis thresholds -------------------------------------------------------
fc_cutoff   <- 1       # |log2FC| >= 1
fdr_cutoff  <- 0.05    # Benjamini-Hochberg adjusted p < 0.05
top_n_sites <- 500     # size of the response-ranked orthologous site set (Fig. 1b, Fig. 6)
set.seed(1)            # bootstrap / permutation reproducibility

# Hallmark sets shown in Fig. 6 and the site set they are drawn from:
#   "top500"        = the 500 orthologous sites of the combined PCA (as in the manuscript)
#   "all_orthologs" = all orthologous sites with complete data in both species
hallmark_sets  <- c("E2F_TARGETS", "MYC_TARGETS_V1", "MYC_TARGETS_V2", "G2M_CHECKPOINT")
hallmark_scope <- "top500"

# ---- packages -------------------------------------------------------------------
suppressPackageStartupMessages({
  library(tidyverse)
  library(matrixStats)
  library(limma)
  library(ggrepel)
  library(svglite)
  library(babelgene)
})
if (packageVersion("dplyr") < "1.1.0") stop("dplyr >= 1.1.0 is required.", call. = FALSE)

# ---- figure style: Arial 8 pt, colour-blind-safe palette ------------------------
pick_font <- function() {
  want <- c("Arial", "Helvetica", "Liberation Sans", "Nimbus Sans")
  if (requireNamespace("systemfonts", quietly = TRUE)) {
    have <- unique(systemfonts::system_fonts()$family)
    hit  <- want[want %in% have]
    if (length(hit)) return(hit[1])
  }
  "sans"   # falls back to the device default sans-serif
}
font_family <- pick_font()
base_size   <- 8

theme_pub <- theme_bw(base_size = base_size, base_family = font_family) +
  theme(panel.grid.minor = element_blank(),
        strip.background = element_rect(fill = "grey95", colour = "grey60"),
        plot.title = element_text(face = "bold", size = base_size + 1),
        legend.key.size = unit(0.35, "cm"))

# Condition always has the same three colours; species is shown by shape/facet/row.
cond_levels    <- c("untreated", "TPA30", "TPA180")
cond_colors    <- c(untreated = "#1B1B1B", TPA30 = "#E69F00", TPA180 = "#D55E00")
cond_shapes    <- c(untreated = 15, TPA30 = 17, TPA180 = 16)
species_colors <- c(Mouse = "#E69F00", Human = "#0072B2")
species_shapes <- c(Mouse = 16, Human = 17)
dir_colors     <- c(Up = "#D55E00", Down = "#0072B2")

# ---- helpers ----------------------------------------------------------------------
pdf_device <- if (isTRUE(capabilities("cairo"))) grDevices::cairo_pdf else grDevices::pdf

save_both <- function(plot, name, w = 6, h = 4) {
  ggsave(file.path(fig_dir, paste0(name, ".pdf")), plot, width = w, height = h, device = pdf_device)
  ggsave(file.path(fig_dir, paste0(name, ".svg")), plot, width = w, height = h, device = svglite::svglite)
  invisible(plot)
}

# pheatmap(..., silent = TRUE) object -> PDF + SVG
save_pheatmap <- function(ph, name, w = 6, h = 6) {
  pdf_device(file.path(fig_dir, paste0(name, ".pdf")), width = w, height = h)
  grid::grid.newpage(); grid::grid.draw(ph$gtable); invisible(dev.off())
  svglite::svglite(file.path(fig_dir, paste0(name, ".svg")), width = w, height = h)
  grid::grid.newpage(); grid::grid.draw(ph$gtable); invisible(dev.off())
}

# European decimal commas; "Filtered", blanks and a literal 0 are "not detected" (NA)
to_num <- function(x) {
  x <- stringr::str_trim(x)
  x[x %in% c("Filtered", "NaN", "", "0")] <- NA
  as.numeric(stringr::str_replace_all(x, ",", "."))
}

# Prints OK / CHECK against the number reported in the manuscript drafts.
# It never stops the pipeline: a CHECK means "compare before you cite".
check <- function(label, observed, expected, tol = 0) {
  obs <- as.numeric(observed); exp <- as.numeric(expected)
  ok  <- length(obs) == length(exp) && all(abs(obs - exp) <= tol + 1e-9)
  cat(sprintf("  [%s] %-50s observed %s | manuscript %s\n", if (ok) " OK  " else "CHECK", label,
              paste(format(round(obs, 2), trim = TRUE), collapse = " / "),
              paste(format(exp, trim = TRUE), collapse = " / ")))
  invisible(ok)
}

# Hallmark gene sets as a named list (msigdbr first, then a local GMT file)
load_hallmark <- function() {
  # a local GMT in the data folder wins (offline, version-pinned); otherwise msigdbr
  if (length(hallmark_gmt) > 0) {
    g <- strsplit(readLines(hallmark_gmt[1]), "\t")
    return(setNames(lapply(g, function(x) x[-(1:2)]), sub("^HALLMARK_", "", vapply(g, `[`, "", 1))))
  }
  if (requireNamespace("msigdbr", quietly = TRUE)) {
    hm <- tryCatch(msigdbr::msigdbr(species = "Homo sapiens", collection = "H"),
                   error = function(e) tryCatch(
                     msigdbr::msigdbr(species = "Homo sapiens", category = "H"),
                     error = function(e2) NULL))
    if (!is.null(hm) && nrow(hm) > 0) return(split(hm$gene_symbol, sub("^HALLMARK_", "", hm$gs_name)))
  }
  if (length(hallmark_gmt) > 0) {
    g <- strsplit(readLines(hallmark_gmt[1]), "\t")
    return(setNames(lapply(g, function(x) x[-(1:2)]), sub("^HALLMARK_", "", vapply(g, `[`, "", 1))))
  }
  stop("No Hallmark gene sets found: install msigdbr (and msigdbdf), or place the MSigDB Hallmark ",
       "GMT file (h.all.v*.Hs.symbols.gmt) in data/.", call. = FALSE)
}

cat(sprintf("Config loaded | font: %s | R %s\n", font_family, getRversion()))
