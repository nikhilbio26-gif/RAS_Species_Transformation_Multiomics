# ============================================================
# 04_fig2_concordance.R  -  Figure 2: mouse vs human log2FC at 180 min
# ============================================================
# Scatter of mouse vs human TPA180/untreated log2FC on the shared orthologous sites.
# Sites are classified with the same thresholds as everywhere else
# (|log2FC| >= 1 and FDR < 0.05, per species):
#   Concordant up / Concordant down / Opposite / Mouse-specific / Human-specific / Flat (both)
# Reported: Pearson r on all sites and on "responsive" sites (significant in >= 1 species).
#
# Input : results/02_diff.rds
# Output: figures/Figure2_concordance_180min.*, Figure2b_class_counts.*,
#         results/concordance_180min_sites.csv, results/concordance_class_counts.csv

source("scripts/00_config.R")
d2 <- readRDS(file.path(res_dir, "02_diff.rds"))
list2env(d2[c("tt_M_TPA180", "tt_H_TPA180", "pairs")], environment())

direction <- function(fc, p) dplyr::case_when(p < fdr_cutoff & fc >=  fc_cutoff ~ "up",
                                              p < fdr_cutoff & fc <= -fc_cutoff ~ "down", TRUE ~ "flat")
shared <- pairs %>%
  dplyr::left_join(tt_M_TPA180 %>% dplyr::select(CollapseKey, m_fc = logFC, m_p = adj.P.Val), by = "CollapseKey") %>%
  dplyr::left_join(tt_H_TPA180 %>% dplyr::select(CollapseKey_h = CollapseKey, h_fc = logFC, h_p = adj.P.Val),
                   by = "CollapseKey_h") %>%
  dplyr::filter(!is.na(m_fc), !is.na(h_fc)) %>%
  dplyr::mutate(m_dir = direction(m_fc, m_p), h_dir = direction(h_fc, h_p),
                class = dplyr::case_when(
                  m_dir == "up"   & h_dir == "up"   ~ "Concordant up",
                  m_dir == "down" & h_dir == "down" ~ "Concordant down",
                  (m_dir == "up" & h_dir == "down") | (m_dir == "down" & h_dir == "up") ~ "Opposite",
                  m_dir != "flat" & h_dir == "flat" ~ "Mouse-specific",
                  m_dir == "flat" & h_dir != "flat" ~ "Human-specific",
                  TRUE ~ "Flat (both)"),
                responsive = m_dir != "flat" | h_dir != "flat")

class_levels <- c("Concordant up", "Concordant down", "Opposite", "Mouse-specific", "Human-specific", "Flat (both)")
class_colors <- c("Concordant up" = "#D55E00", "Concordant down" = "#0072B2", "Opposite" = "#CC79A7",
                  "Mouse-specific" = "#E69F00", "Human-specific" = "#009E73", "Flat (both)" = "grey80")
shared$class <- factor(shared$class, class_levels)

r_all  <- cor(shared$m_fc, shared$h_fc)
r_resp <- cor(shared$m_fc[shared$responsive], shared$h_fc[shared$responsive])
n_resp <- sum(shared$responsive)
cat(sprintf("Orthologous sites with a 180-min test in both species: %d\n", nrow(shared)))
cat(sprintf("Pearson r, all sites: %.3f | responsive sites (n = %d): %.3f\n", r_all, n_resp, r_resp))

cls <- shared %>% dplyr::count(class, .drop = FALSE) %>% dplyr::mutate(percent = round(100 * n / sum(n), 1))
print(cls)
readr::write_csv(cls, file.path(res_dir, "concordance_class_counts.csv"))
readr::write_csv(dplyr::select(shared, CollapseKey, CollapseKey_h, human_gene, m_fc, m_p, h_fc, h_p, class),
                 file.path(res_dir, "concordance_180min_sites.csv"))

cat("\nCompare with the manuscript text (these were flagged for re-verification on the de-duplicated pair set):\n")
check("sites in the concordance analysis", nrow(shared), 3561)
check("Pearson r, all sites", r_all, 0.06, tol = 0.005)
check("Pearson r, responsive sites", r_resp, 0.10, tol = 0.005)

p <- ggplot(shared[order(shared$class != "Flat (both)"), ], aes(m_fc, h_fc, colour = class)) +
  geom_hline(yintercept = 0, colour = "grey60", linewidth = 0.3) +
  geom_vline(xintercept = 0, colour = "grey60", linewidth = 0.3) +
  geom_abline(slope = 1, linetype = "dashed", colour = "grey50", linewidth = 0.3) +
  geom_point(size = 0.8, alpha = 0.7, stroke = 0) +
  annotate("text", x = -Inf, y = Inf, hjust = -0.05, vjust = 1.4, size = 2.8, family = font_family, lineheight = 1.1,
           label = sprintf("All sites: r = %.2f (n = %d)\nResponsive sites: r = %.2f (n = %d)", r_all, nrow(shared), r_resp, n_resp)) +
  scale_colour_manual(values = class_colors, name = NULL) +
  guides(colour = guide_legend(override.aes = list(size = 2, alpha = 1))) +
  labs(title = "Fig. 2  Mouse and human response to TPA at 180 min",
       x = "Mouse log2FC (180 min / untreated)", y = "Human log2FC (180 min / untreated)") +
  theme_pub + coord_equal()
save_both(p, "Figure2_concordance_180min", w = 4.8, h = 4.2)

pb <- ggplot(cls, aes(n, factor(class, rev(class_levels)), fill = class)) +
  geom_col(width = 0.7) +
  geom_text(aes(label = sprintf("%d (%.1f%%)", n, percent)), hjust = -0.1, size = 2.6, family = font_family) +
  scale_fill_manual(values = class_colors, guide = "none") +
  scale_x_continuous(expand = expansion(mult = c(0, 0.3))) +
  labs(title = "Fig. 2b  Site classes", x = "orthologous sites", y = NULL) + theme_pub
save_both(pb, "Figure2b_class_counts", w = 3.8, h = 2.2)
