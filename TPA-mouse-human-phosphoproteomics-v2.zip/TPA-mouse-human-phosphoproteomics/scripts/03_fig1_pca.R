# ============================================================
# 03_fig1_pca.R  -  Figure 1: PCA of the TPA response
# ============================================================
# Fig 1a  PCA of mouse (M) and human (H) separately, each on its own 500 most variable
#         sites with complete data (no ortholog restriction)
# Fig 1b  mouse + human on ONE shared PCA built from 1:1 orthologous sites
#         - each site is z-scored WITHIN species (rows), then the two species are joined
#         - the 500 sites are the ones with the largest TPA response: ranked by
#           max |log2FC| over {mouse, human} x {30, 180 min} from the limma tables
#           (NOT by post-z-score variance, which is uninformative because z-scoring gives
#           every site the same variance within each species)
# Fig 1c  same joint PCA on ALL orthologous sites with complete data (supplement)
# Stats   bootstrap of the mouse-human centroid distance; PERMANOVA (optional, needs vegan)
#
# Input : results/01_loaded.rds, results/02_diff.rds
# Output: figures/Figure1a_*, Figure1b_*, Figure1c_*; results/PCA_top500_orthologs.csv,
#         results/centroid_distances.csv, results/03_pca.rds

source("scripts/00_config.R")
loaded <- readRDS(file.path(res_dir, "01_loaded.rds")); mouse <- loaded$mouse; human <- loaded$human
d2 <- readRDS(file.path(res_dir, "02_diff.rds"))
list2env(d2[c("tt_M_TPA30", "tt_M_TPA180", "tt_H_TPA30", "tt_H_TPA180", "keys_kept", "m_cols", "h_cols")], environment())

add_hulls <- function(df, by) df %>% dplyr::group_by(dplyr::across(dplyr::all_of(by))) %>%
  dplyr::filter(dplyr::n() >= 3) %>% dplyr::slice(chull(PC1, PC2)) %>% dplyr::ungroup()
ve_of <- function(pc) round(100 * pc$sdev^2 / sum(pc$sdev^2), 1)

# ---- Fig 1a: each species on its own top-variable sites -------------------------------
own_pca <- function(norm, meta, cl, species) {
  m   <- dplyr::filter(meta, cell_line == cl)
  sub <- norm[, m$label, drop = FALSE]; sub <- sub[complete.cases(sub), , drop = FALSE]
  top <- head(order(rowVars(sub), decreasing = TRUE), min(500, nrow(sub)))
  pc  <- prcomp(t(sub[top, ]), center = TRUE, scale. = FALSE)
  ve  <- ve_of(pc)
  as.data.frame(pc$x[, 1:2]) %>% tibble::rownames_to_column("label") %>%
    dplyr::left_join(m, by = "label") %>%
    dplyr::mutate(species = species, panel = sprintf("%s (PC1 %.1f%%, PC2 %.1f%%)", species, ve[1], ve[2]))
}
pca_a <- dplyr::bind_rows(own_pca(mouse$norm, mouse$meta, "M", "Mouse"),
                          own_pca(human$norm, human$meta, "H", "Human")) %>%
  dplyr::mutate(condition = factor(condition, cond_levels),
                panel = factor(panel, unique(panel)))
hull_a <- add_hulls(pca_a, c("panel", "condition"))

p1a <- ggplot(pca_a, aes(PC1, PC2, colour = condition)) +
  geom_polygon(data = hull_a, aes(fill = condition), alpha = 0.15, colour = NA) +
  geom_point(aes(shape = condition), size = 2) +
  facet_wrap(~panel, scales = "free") +
  scale_colour_manual(values = cond_colors, name = NULL) +
  scale_fill_manual(values = cond_colors, name = NULL) +
  scale_shape_manual(values = cond_shapes, name = NULL) +
  labs(title = "Fig. 1a  TPA response, each species on its own most variable sites") +
  theme_pub + theme(legend.position = "bottom")
save_both(p1a, "Figure1a_PCA_side_by_side", w = 6.5, h = 3.4)

# ---- joint space ---------------------------------------------------------------------
mv <- mouse$norm[keys_kept$CollapseKey,   m_cols, drop = FALSE]
hv <- human$norm[keys_kept$CollapseKey_h, h_cols, drop = FALSE]
joint_mat <- cbind(t(scale(t(mv))), t(scale(t(hv))))          # sites x 18 samples, z-scored within species
meta_all  <- dplyr::bind_rows(mouse$meta, human$meta) %>% dplyr::select(label, cell_line, condition)
cond_of_cols <- meta_all$condition[match(colnames(joint_mat), meta_all$label)]
species_of_cols <- ifelse(colnames(joint_mat) %in% m_cols, "Mouse", "Human")

# response magnitude of every orthologous site (from the differential tables)
mag_df <- keys_kept %>%
  dplyr::left_join(tt_M_TPA30  %>% dplyr::select(CollapseKey, m30  = logFC), by = "CollapseKey") %>%
  dplyr::left_join(tt_M_TPA180 %>% dplyr::select(CollapseKey, m180 = logFC), by = "CollapseKey") %>%
  dplyr::left_join(tt_H_TPA30  %>% dplyr::select(CollapseKey_h = CollapseKey, h30  = logFC), by = "CollapseKey_h") %>%
  dplyr::left_join(tt_H_TPA180 %>% dplyr::select(CollapseKey_h = CollapseKey, h180 = logFC), by = "CollapseKey_h") %>%
  dplyr::mutate(mag = pmax(abs(m30), abs(m180), abs(h30), abs(h180), na.rm = TRUE))
top500_idx <- order(mag_df$mag, decreasing = TRUE)[seq_len(min(top_n_sites, nrow(mag_df)))]

plot_joint <- function(idx, title, name) {
  pc <- prcomp(t(joint_mat[idx, ]), center = TRUE, scale. = FALSE); ve <- ve_of(pc)
  sc <- as.data.frame(pc$x[, 1:2]) %>% tibble::rownames_to_column("label") %>%
    dplyr::mutate(species = factor(ifelse(label %in% m_cols, "Mouse", "Human"), c("Mouse", "Human")),
                  condition = factor(meta_all$condition[match(label, meta_all$label)], cond_levels))
  hull <- add_hulls(sc, c("species", "condition"))
  cen  <- sc %>% dplyr::group_by(species, condition) %>%
    dplyr::summarise(PC1 = mean(PC1), PC2 = mean(PC2), .groups = "drop") %>% dplyr::arrange(species, condition)
  p <- ggplot(sc, aes(PC1, PC2, colour = condition)) +
    geom_polygon(data = hull, aes(fill = condition, group = interaction(species, condition)), alpha = 0.12, colour = NA) +
    geom_path(data = cen, aes(group = species, linetype = species), colour = "grey30", linewidth = 0.5,
              arrow = grid::arrow(length = grid::unit(0.12, "cm"), type = "closed")) +
    geom_point(aes(shape = species), size = 1.8, alpha = 0.9) +
    geom_point(data = cen, aes(shape = species), size = 3.4, stroke = 0.8, fill = "white", colour = "black") +
    scale_colour_manual(values = cond_colors, name = "Condition") +
    scale_fill_manual(values = cond_colors, name = "Condition") +
    scale_shape_manual(values = species_shapes, name = "Species") +
    scale_linetype_manual(values = c(Mouse = "solid", Human = "dashed"), name = "Trajectory") +
    labs(title = title, subtitle = sprintf("%d orthologous sites | PC1 %.1f%%, PC2 %.1f%% | open symbols = centroids; arrows = untreated > 30 > 180 min",
                                           length(idx), ve[1], ve[2]),
         x = sprintf("PC1 (%.1f%%)", ve[1]), y = sprintf("PC2 (%.1f%%)", ve[2])) +
    theme_pub + theme(plot.subtitle = element_text(size = base_size - 1))
  save_both(p, name, w = 5.2, h = 4.6)
  ve
}

cat("Joint PCA (z-scored within species)\n")
ve_top <- plot_joint(top500_idx, "Fig. 1b  Mouse and human on shared orthologous sites (top 500 by response)",
                     "Figure1b_PCA_joint_orthologs")
ve_all <- plot_joint(seq_len(nrow(joint_mat)), "Fig. 1c  Mouse and human on all orthologous sites with complete data",
                     "Figure1c_PCA_joint_all_sites")
check("Fig 1b PC1 / PC2 (top 500)", ve_top[1:2], c(31.1, 26.9), tol = 0.05)
check("Fig 1c PC1 / PC2 (all sites)", ve_all[1:2], c(27.9, 21.1), tol = 0.05)

# ---- save the 500 sites (used by Fig. 6) ---------------------------------------------------
site_label_m <- setNames(mouse$sites$label, mouse$sites$CollapseKey)
site_label_h <- setNames(human$sites$label, human$sites$CollapseKey)
top500_tbl <- mag_df[top500_idx, ] %>%
  dplyr::mutate(mouse_site = site_label_m[CollapseKey], human_site = site_label_h[CollapseKey_h]) %>%
  dplyr::select(CollapseKey, CollapseKey_h, human_gene, mouse_site, human_site, m30, m180, h30, h180, mag)
readr::write_csv(top500_tbl, file.path(res_dir, "PCA_top500_orthologs.csv"))

# ---- mouse-human centroid distance: baseline / 30 / 180 min ---------------------------------
col_mean <- function(cols_idx) rowMeans(joint_mat[, cols_idx, drop = FALSE])
diff_by_cond <- sapply(cond_levels, function(cn)
  col_mean(which(species_of_cols == "Mouse" & cond_of_cols == cn)) -
  col_mean(which(species_of_cols == "Human" & cond_of_cols == cn)))      # sites x 3 (mouse - human)
colnames(diff_by_cond) <- c("baseline", "30 min", "180 min")
dist_top <- sqrt(colSums(diff_by_cond[top500_idx, ]^2))
cat("\nCentroid distance, top-500 PCA space (baseline / 30 / 180):", round(dist_top, 1), "\n")
check("centroid distance in the top 500", dist_top, c(23.5, 13.7, 26.1), tol = 0.05)

# bootstrap: 1,000 resamples (with replacement) of top_n_sites sites from ALL complete orthologous sites
sq   <- diff_by_cond^2
boot <- t(replicate(1000, sqrt(colSums(sq[sample(nrow(sq), top_n_sites, replace = TRUE), , drop = FALSE]))))
dist_tbl <- tibble::tibble(timepoint = colnames(diff_by_cond),
                           distance_top500 = as.numeric(dist_top),
                           boot_mean = colMeans(boot),
                           ci_low  = apply(boot, 2, quantile, 0.025),
                           ci_high = apply(boot, 2, quantile, 0.975))
print(dist_tbl)
readr::write_csv(dist_tbl, file.path(res_dir, "centroid_distances.csv"))
check("bootstrap mean distance (baseline/30/180)", dist_tbl$boot_mean, c(22.4, 14.3, 25.5), tol = 0.3)

# ---- PERMANOVA on the joint space (optional) --------------------------------------------------
if (requireNamespace("vegan", quietly = TRUE)) {
  cat("\nPERMANOVA (vegan::adonis2, 999 permutations)\n")
  meta_pm <- data.frame(species = factor(species_of_cols), condition = factor(cond_of_cols, cond_levels))
  dm <- dist(t(joint_mat))
  ad <- vegan::adonis2(dm ~ species * condition, data = meta_pm, permutations = 999, by = "terms")
  print(ad)
  base_i <- which(cond_of_cols == "untreated")
  ad_b <- vegan::adonis2(dist(t(joint_mat[, base_i])) ~ species, data = meta_pm[base_i, ], permutations = 999)
  cat("Baseline-only (untreated) species effect:\n"); print(ad_b)
  capture.output(print(ad), print(ad_b), file = file.path(res_dir, "PERMANOVA.txt"))
  cat("Note: the species main effect is ~0 by construction (within-species z-scoring).\n")
} else cat("[skip] PERMANOVA: install.packages('vegan')\n")

saveRDS(list(top500_idx = top500_idx, mag_df = mag_df, joint_mat = joint_mat, top500_tbl = top500_tbl),
        file.path(res_dir, "03_pca.rds"))
cat("Saved results/03_pca.rds\n")
