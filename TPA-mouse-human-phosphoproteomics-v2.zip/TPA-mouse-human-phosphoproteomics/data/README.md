# Input data (not in git)

Place the Spectronaut PTM reports here with these exact names:

| File | Format |
|---|---|
| `TPA_Mouse_Phospho_Report.tsv` | tab-delimited, point decimals |
| `TPA_Human_Phospho_Report.csv` | semicolon-delimited, decimal commas |

Optional: `h.all.v*.Hs.symbols.gmt` (MSigDB Hallmark). If present it is used instead of msigdbr.

Sample-to-column maps are in `../metadata/`. Raw files are git-ignored; deposit them in PRIDE/MassIVE
and link the accession in the main README.
