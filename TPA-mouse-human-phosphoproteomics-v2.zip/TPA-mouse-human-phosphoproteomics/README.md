# TPA phosphoproteomics: conserved early response, divergent late response in mouse and human cells

Analysis code for a DIA phosphoproteomics experiment comparing isogenic **mouse** (M parental, MR = +HRAS-G12V) and
**human** (H parental, HR = +HRAS-G12V, HT = small-t / PP2A-inhibited) cells at 0, 30 and 180 min of TPA (3 replicates each).
Spectronaut PTM reports go in, manuscript figures and tables come out.

## Figures produced

| Script | Output | Content |
|---|---|---|
| `01_load_and_normalise.R` | `results/01_loaded.rds` | Phospho (STY) filter, log2, median normalisation per species |
| `02_differential_and_orthologs.R` | `results/TPA_*_vs_untreated.csv`, `ortholog_site_pairs.csv` | limma TPA30/TPA180 vs untreated (parental lines); 1:1 ortholog site matching |
| `03_fig1_pca.R` | **Fig. 1a-c** | PCA: own-species, joint top-500 orthologous sites, joint all sites; centroid distances, bootstrap, PERMANOVA |
| `04_fig2_concordance.R` | **Fig. 2** | Human vs mouse log2FC at 180 min, concordance classes |
| `05_fig3_motifs.R` | **Fig. 3** | motif-x on up-regulated S/T sites, kinase-family pie charts (180 and 30 min), Pro(+1) fraction test |
| `06_fig4_top20_30min.R` | **Fig. 4a/b** | Top 20 concordantly up / down sites at 30 min (heatmaps) |
| `07_fig5_erk.R` | **Fig. 5** | ERK1/ERK2 activation-loop (TEY) phosphorylation bar plots, mouse and human |
| `08_fig6_hallmark_orthologous_sites.R` | **Fig. 6a-c** | Phosphosites on E2F / MYC / G2M Hallmark proteins, orthologous sites, time-series |

All figures are written as PDF and SVG (Arial/Helvetica 8 pt, colour-blind-safe palette).

## Quick start

```r
source("environment/install_packages.R")   # once
```
```bash
# put the two Spectronaut reports in data/ (see data/README.md), then from the repo root:
Rscript scripts/run_all.R
```
Each script can also be run alone (they read the `.rds` files written by earlier steps). Thresholds
(`|log2FC| >= 1`, FDR < 0.05, top 500 sites, Hallmark sets) are in `scripts/00_config.R`.

## Layout
```
scripts/      00_config.R, 01-08 analysis scripts, run_all.R
metadata/     sample -> cell line / condition / replicate maps (one CSV per species)
data/         raw reports (git-ignored); see data/README.md
figures/      generated (git-ignored)
results/      generated tables and .rds (git-ignored)
environment/  install_packages.R
tests/        synthetic-data smoke test
```

## Methods in brief
- **Quantification**: sites with `PTM.ModificationTitle == "Phospho (STY)"`; "Filtered"/NaN/0 -> NA; log2; median normalisation across all samples of a species. Sites need >= 2 valid values in >= 1 line x condition group.
- **Differential analysis**: limma (`eBayes(trend = TRUE, robust = TRUE)`) on the parental lines, TPA30 and TPA180 vs untreated; sites need >= 2 valid values in >= 2 conditions. Significant: |log2FC| >= 1 and BH-FDR < 0.05.
- **Orthologous sites**: babelgene 1:1 orthologs; a mouse and a human site pair when human gene, residue and the 15-mer flanking sequence match exactly. Pairs with complete data in all 9 + 9 parental samples enter the joint PCA.
- **Joint PCA**: intensities z-scored within species. The 500 sites are the top 500 by max |log2FC| over {mouse, human} x {30, 180 min} from the limma tables. They are selected by response magnitude, **not** by post-z-score variance.
- **Motifs**: motif-x (`rmotifx`, central residue S/T, >= 10 sequences, p < 1e-4) on up-regulated S/T sites against all quantified S/T sites of that species; motifs grouped into proline-directed (ERK/MAPK), basophilic (PKC/RSK) and other.
- **ERK sites** are found from the TEY motif on MAPK1/MAPK3, not from residue numbers.
- **Hallmark panel (Fig. 6)** shows phosphosites on proteins whose genes are Hallmark members. It reports site behaviour, **not** E2F/MYC transcription-factor activity.

## Checks against manuscript numbers
Scripts print `[ OK ]` / `[CHECK]` lines comparing results with the numbers in the manuscript drafts (limma counts,
5850 ortholog pairs, 2124 complete-data pairs, PCA variance, centroid distances, ERK log2FC, motif family counts, concordance r).
A `[CHECK]` never stops the pipeline; it means "compare before you cite".

## Known caveats (please read before submission)
1. **Concordance numbers** (3,561 sites, r = 0.06 all / 0.10 responsive) were flagged for re-verification on de-duplicated ortholog pairs; run script 04 on the real data and update the text from its output.
2. **Bootstrap of centroid distance** resamples 500 sites with replacement from all 2,124 pairs. This scheme is an assumption; confirm it reproduces the manuscript CI (e.g. 14.3 at 30 min).
3. **Pro(+1) fraction test**: `prop.test` with and without continuity correction are both written to `results/proline_fraction_test.csv`; use the one matching the stated P values.
4. **Hallmark enrichment is weak**: protein-level ORA/GSEA gave no FDR < 0.05, and E2F/MYC/G2M phosphosites are not enriched for the shared 30-min response. Large log2FC values in the top-ranked sets partly reflect selection for extreme values (winner's curse) and low basal intensity.
5. Duplicate-value pairs (same peptide, ambiguous localisation) are counted once in Fig. 6.

## Testing without the real data
`tests/make_synthetic_data.R` writes random Spectronaut-style reports plus a toy Hallmark GMT; see `tests/README.md`.
The pipeline was run end-to-end on this synthetic data (all eight scripts complete, 26 figure files). Motif-x was
tested only with a stub `rmotifx` (flow and plotting, not the real algorithm), and Hallmark loading only from a GMT file
(not msigdbr). On synthetic data the `[CHECK]` lines are expected to fail.

## Data availability
Deposit raw files in PRIDE/MassIVE and add the accession here: `PXD______`.

## License and citation
MIT (see `LICENSE`). Citation metadata in `CITATION.cff` (fill in authors / DOI).
