# Smoke test on synthetic data

```bash
TPA_DATA_DIR=tests/synthetic_data Rscript tests/make_synthetic_data.R
TPA_DATA_DIR=tests/synthetic_data TPA_OUT_DIR=tests/synthetic_out Rscript scripts/run_all.R
```
Outputs go to `tests/synthetic_out/` (git-ignored). The data are random: figures have no biological meaning and
manuscript `[CHECK]` lines are expected to fail. The test only shows that every script runs and writes its figures.
Script 05 needs the real `rmotifx` package; the synthetic run needs it installed too.
The Hallmark GMT written into `tests/synthetic_data/` is picked up automatically (a local GMT takes priority over msigdbr).
