# ============================================================
# tests/make_synthetic_data.R
# Writes SYNTHETIC Spectronaut-style reports so the pipeline can be smoke-tested without
# the real data. The numbers are random: figures made from this data have NO biological
# meaning and the "[CHECK]" lines against manuscript values are expected to fail.
#
# What it does plant, so every code path is exercised:
#   - real mouse/human 1:1 ortholog gene symbols (from babelgene) with identical 15-mer flanks
#   - mouse- and human-specific sites that cannot be paired
#   - a TPA response in ~35 % of sites (partly shared between species, partly not)
#   - Pro at +1 / Arg at -3 in responsive sites, so motif-x has something to find
#   - ERK1/2 (MAPK3/MAPK1) T-E-Y activation-loop sites with a strong response
#   - missing values ("Filtered"), human decimal commas, the odd H8 file name, MR/HR/HT lines
#   - a small synthetic Hallmark GMT (E2F, MYC V1/V2, G2M, glycolysis, hypoxia)
#
# Usage (from the repository root):
#   Rscript tests/make_synthetic_data.R
#   TPA_DATA_DIR=tests/synthetic_data TPA_OUT_DIR=tests/synthetic_out Rscript scripts/run_all.R
# ============================================================

suppressPackageStartupMessages({ library(babelgene); library(dplyr); library(readr) })
set.seed(42)
out <- Sys.getenv("TPA_DATA_DIR", "tests/synthetic_data")
dir.create(out, showWarnings = FALSE, recursive = TRUE)

meta_m <- read_csv("metadata/sample_metadata_mouse.csv", show_col_types = FALSE)
meta_h <- read_csv("metadata/sample_metadata_human.csv", show_col_types = FALSE)

# ---- genes: 1:1 mouse-human pairs ---------------------------------------------------------
og <- babelgene:::orthologs_df
og <- og[og$taxon_id == 10090 & og$support_n >= 8, c("human_symbol", "symbol")]
og <- og[!duplicated(og$human_symbol) & !duplicated(og$symbol), ]
og <- og[grepl("^[A-Z0-9]+$", og$human_symbol) & !(og$human_symbol %in% c("MAPK1", "MAPK3")), ]
og <- og[sample(nrow(og), 1200), ]
genes <- rbind(data.frame(human_symbol = c("MAPK1", "MAPK3"), symbol = c("Mapk1", "Mapk3")), og)

aa20 <- strsplit("ADEFGHIKLMNPQRSTVWY", "")[[1]]
rand_flank <- function(center) { x <- sample(aa20, 15, TRUE); x[8] <- center; paste(x, collapse = "") }

# ---- ortholog site table ----------------------------------------------------------------------
sites <- bind_rows(lapply(seq_len(nrow(genes)), function(i) {
  n <- sample(2:4, 1)
  aa <- sample(c("S", "T", "Y"), n, TRUE, prob = c(0.8, 0.15, 0.05))
  tibble(hs = genes$human_symbol[i], ms = genes$symbol[i], aa = aa,
         loc = sample(20:900, n), flank = vapply(aa, rand_flank, ""))
}))
# ERK activation loops: Tyr (flank pos 6-8 = TEY) and Thr (pos 8-10 = TEY)
erk_y <- "HTGFLTEYVATRWYR"; erk_t <- "DHDHTGFTEYVATRW"
erk <- tibble(hs = c("MAPK1", "MAPK1", "MAPK3", "MAPK3"), ms = c("Mapk1", "Mapk1", "Mapk3", "Mapk3"),
              aa = c("Y", "T", "Y", "T"), loc = c(187, 185, 204, 202), flank = c(erk_y, erk_t, erk_y, erk_t))
sites <- bind_rows(erk, sites[!(sites$hs %in% c("MAPK1", "MAPK3")), ])
sites$id <- seq_len(nrow(sites))

resp <- runif(nrow(sites)) < 0.35
resp[1:4] <- TRUE
sites$resp <- resp
prol <- resp & sites$aa %in% c("S", "T") & runif(nrow(sites)) < 0.5
baso <- resp & !prol & sites$aa %in% c("S", "T") & runif(nrow(sites)) < 0.4
substr(sites$flank[prol], 9, 9)  <- "P"
substr(sites$flank[baso], 5, 5)  <- "R"
sites$flank[1:4] <- c(erk_y, erk_t, erk_y, erk_t)   # restore the planted loops

# per-species response (log2FC) at 30 / 180 min; ~half shared between species
eff <- function(n) cbind(e30 = rnorm(n, 0.8, 1.3), e180 = rnorm(n, 0.5, 1.6))
Em <- eff(nrow(sites)); Eh_own <- eff(nrow(sites))
share <- runif(nrow(sites)) < 0.5
Eh <- Eh_own; Eh[share, ] <- Em[share, ] * 0.8 + Eh_own[share, ] * 0.4
Em[!resp, ] <- matrix(rnorm(sum(!resp) * 2, 0, 0.15), ncol = 2); Eh[!resp, ] <- matrix(rnorm(sum(!resp) * 2, 0, 0.15), ncol = 2)
Em[1:4, ] <- cbind(c(1.7, 1.7, 1.6, 1.6), c(0.5, 0.5, 0.4, 0.4))
Eh[1:4, ] <- cbind(c(2.6, 2.6, 2.6, 2.6), c(1.0, 1.0, 1.0, 1.0))

# species-specific extra sites (no counterpart in the other species)
extra <- function(n, prefix) tibble(hs = sample(genes$human_symbol, n, TRUE), aa = sample(c("S", "T"), n, TRUE),
                                    loc = sample(20:900, n), flank = vapply(rep("S", n), rand_flank, ""))
ex_m <- extra(250, "m"); ex_h <- extra(250, "h")

make_report <- function(species, meta, delim, decimal_comma) {
  is_m <- species == "mouse"
  base <- sites; E <- if (is_m) Em else Eh
  gene_col <- if (is_m) base$ms else base$hs
  rows <- tibble(gene = gene_col, aa = base$aa, loc = base$loc, flank = base$flank, e30 = E[, 1], e180 = E[, 2])
  if (!is_m) {   # human: perturb the flank of ~8 % of pairs so a few orthologous sites do not match
    brk <- runif(nrow(rows)) < 0.08 & seq_len(nrow(rows)) > 4
    substr(rows$flank[brk], 3, 3) <- "W"
  }
  ex <- if (is_m) ex_m else ex_h
  ex$ms <- genes$symbol[match(ex$hs, genes$human_symbol)]
  rows <- bind_rows(rows, tibble(gene = if (is_m) ex$ms else ex$hs, aa = ex$aa, loc = ex$loc,
                                 flank = ex$flank, e30 = rnorm(nrow(ex), 0, .3), e180 = rnorm(nrow(ex), 0, .3)))
  rows$loc <- rows$loc + if (is_m) 0 else sample(-3:3, nrow(rows), TRUE)     # residue numbers differ between species
  n <- nrow(rows)
  rows$level <- rnorm(n, 22, 1.8)
  mat <- sapply(seq_len(nrow(meta)), function(j) {
    cl <- meta$cell_line[j]; cond <- meta$condition[j]
    shift <- if (cl %in% c("M", "H")) 0 else rnorm(n, 0, 0.5)               # genotype baseline shift (MR, HR, HT)
    resp <- switch(cond, untreated = 0, TPA30 = rows$e30, TPA180 = rows$e180)
    rows$level + shift + resp + rnorm(n, 0, 0.3)
  })
  vals <- 2^mat
  vals[matrix(runif(length(vals)) < 0.02, nrow(vals))] <- NA                # sporadic missing values
  fmt <- function(v) { s <- ifelse(is.na(v), "Filtered", format(v, digits = 10, scientific = FALSE, trim = TRUE))
                       if (decimal_comma) sub("\\.", ",", s) else s }
  out_df <- tibble(
    PG.ProteinGroups = paste0("P", seq_len(n)), PG.Genes = rows$gene, PTM.ProteinId = paste0("P", seq_len(n)),
    PTM.CollapseKey = paste0(rows$gene, "_", rows$aa, rows$loc, "_", seq_len(n)),
    PTM.ModificationTitle = "Phospho (STY)", PTM.SiteAA = rows$aa, PTM.SiteLocation = rows$loc,
    PTM.SiteProbability = "1", PTM.Multiplicity = "1", PTM.FlankingRegion = rows$flank)
  for (j in seq_len(nrow(meta))) out_df[[meta$column[j]]] <- fmt(vals[, j])
  out_df
}
write_delim(make_report("mouse", meta_m, "\t", FALSE), file.path(out, "TPA_Mouse_Phospho_Report.tsv"), delim = "\t")
write_delim(make_report("human", meta_h, ";",  TRUE),  file.path(out, "TPA_Human_Phospho_Report.csv"), delim = ";")

# ---- tiny synthetic Hallmark GMT ----------------------------------------------------------------
pool <- genes$human_symbol
sets <- list(HALLMARK_E2F_TARGETS = 150, HALLMARK_MYC_TARGETS_V1 = 200, HALLMARK_MYC_TARGETS_V2 = 58,
             HALLMARK_G2M_CHECKPOINT = 200, HALLMARK_GLYCOLYSIS = 200, HALLMARK_HYPOXIA = 200)
writeLines(vapply(names(sets), function(s) paste(c(s, "synthetic", sample(pool, sets[[s]])), collapse = "\t"), ""),
           file.path(out, "h.all.vSYNTHETIC.Hs.symbols.gmt"))
cat("Synthetic data written to", out, "\n")
