# Installs every package the pipeline needs (R >= 4.2; dplyr >= 1.1.0).
cran <- c("tidyverse", "matrixStats", "ggrepel", "svglite", "babelgene", "pheatmap",
          "systemfonts", "vegan", "msigdbr", "rmotifx")
bioc <- c("limma")
missing_cran <- setdiff(cran, rownames(installed.packages()))
if (length(missing_cran)) install.packages(missing_cran)
if (!requireNamespace("BiocManager", quietly = TRUE)) install.packages("BiocManager")
missing_bioc <- setdiff(bioc, rownames(installed.packages()))
if (length(missing_bioc)) BiocManager::install(missing_bioc, ask = FALSE)
# msigdbr >= 10 also needs msigdbdf; if it is unavailable, put the MSigDB Hallmark GMT in data/ instead.
if (!requireNamespace("msigdbdf", quietly = TRUE))
  try(install.packages("msigdbdf", repos = c("https://igordot.r-universe.dev", getOption("repos"))), silent = TRUE)
cat("Done. sessionInfo() is written to results/sessionInfo.txt by script 01.\n")
