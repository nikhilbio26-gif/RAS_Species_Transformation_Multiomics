# ==============================================================================
# File        : 01_deseq2.R
# Project     : promoter-motif-ras (promoter motif analysis of the RAS response, mouse vs human)
# Description : Pooled DESeq2 models (both cell lines, design ~ CellLine + Condition) per species.
# Input       : data/Mouse_RNA_CountFile.xlsx, data/Human_RNA_CountFile.xlsx (optional: data/*_metadata.csv)
# Output      : results/deseq2/*.csv (log2FC, SE, Wald stat, p, padj, symbol)
# Author      : Nikhil Gupta
# Created     : 2026-11-06
# Environment : R 4.3.3, Bioconductor 3.18 (see sessionInfo_*.txt written to results/)
# Run from    : repository root
# ==============================================================================

suppressPackageStartupMessages({
  library(readxl); library(DESeq2); library(dplyr); library(readr)
  library(AnnotationDbi); library(org.Mm.eg.db); library(org.Hs.eg.db)
})
source("config.R"); fix_masks()

read_counts <- function(f) {
  if (!file.exists(f)) stop("Count file not found: ", f, " (see README, 'Input data')")
  x   <- readxl::read_excel(f)
  ids <- as.character(x[[1]])
  m   <- as.matrix(x[, -1]); rownames(m) <- ids; storage.mode(m) <- "numeric"
  stopifnot("Missing/empty gene IDs"  = !anyNA(ids) && all(trimws(ids) != ""),
            "Duplicated gene IDs"     = !anyDuplicated(ids),
            "NA in counts"            = !anyNA(m),
            "Negative counts"         = all(m >= 0),
            "Counts must be integers" = all(m == round(m)))
  m
}

# Sample metadata. If data/<species>_metadata.csv exists (columns: Sample, CellLine, Condition)
# it is used. Otherwise it is parsed from sample names (adjust patterns to YOUR names).
make_meta <- function(samples, species) {
  f <- file.path("data", paste0(species, "_metadata.csv"))
  if (file.exists(f)) {
    m <- read.csv(f, stringsAsFactors = FALSE)
    stopifnot(all(c("Sample", "CellLine", "Condition") %in% names(m)), setequal(m$Sample, samples))
    m <- m[match(samples, m$Sample), ]
  } else if (species == "mouse") {
    m <- data.frame(Sample = samples,
                    CellLine  = ifelse(grepl("^M1", samples), "M1", "M2"),
                    Condition = ifelse(grepl("R", samples), "RAS", "L"))
  } else {
    m <- data.frame(Sample = samples,
                    CellLine  = ifelse(grepl("^H1", samples), "H1", "H2"),
                    Condition = dplyr::case_when(grepl("S", samples) ~ "ST",
                                                 grepl("R", samples) ~ "RAS", TRUE ~ "L"))
  }
  m$CellLine  <- factor(m$CellLine)
  m$Condition <- factor(m$Condition, levels = intersect(c("L", "RAS", "ST"), unique(m$Condition)))
  rownames(m) <- m$Sample
  m
}

fit_pooled <- function(counts, meta) {
  stopifnot(identical(rownames(meta), colnames(counts)))
  d <- DESeqDataSetFromMatrix(counts, meta, design = ~ CellLine + Condition)
  d <- d[rowSums(counts(d) >= cfg$min_count) >= cfg$min_samples, ]
  DESeq(d)
}

tidy_res <- function(res, orgdb, contrast_label) {
  df <- as.data.frame(res)
  df$GeneID     <- rownames(df)
  df$GeneSymbol <- unname(AnnotationDbi::mapIds(orgdb, keys = df$GeneID, keytype = "ENTREZID",
                                                column = "SYMBOL", multiVals = "first"))
  df$contrast <- contrast_label
  df[, c("GeneID", "GeneSymbol", "contrast", "baseMean", "log2FoldChange", "lfcSE", "stat", "pvalue", "padj")]
}

for (sp in c("mouse", "human")) {
  counts <- read_counts(cfg[[paste0(sp, "_counts")]])
  meta   <- make_meta(colnames(counts), sp)
  cat("\n==", sp, "design (CellLine x Condition) ==\n"); print(table(meta$CellLine, meta$Condition))
  if (any(table(meta$CellLine, meta$Condition) == 0)) stop("Empty design cell: check sample-name parsing / metadata")
  write_csv(meta, file.path(cfg$out_dir, "deseq2", paste0(sp, "_sample_metadata.csv")))

  dds <- fit_pooled(counts, meta)
  cat(sp, "genes tested:", nrow(dds), "\n")
  orgdb <- if (sp == "mouse") org.Mm.eg.db else org.Hs.eg.db

  contrasts <- if (sp == "mouse") list(c("RAS", "L")) else list(c("RAS", "L"), c("ST", "RAS"))
  for (ct in contrasts) {
    lab <- paste0(sp, "_", ct[1], "_vs_", ct[2])
    out <- tidy_res(results(dds, contrast = c("Condition", ct[1], ct[2])), orgdb, lab)
    write_csv(out, file.path(cfg$out_dir, "deseq2", paste0(lab, ".csv")))
    cat(lab, ": ", sum(!is.na(out$padj) & out$padj < 0.05), " genes at FDR < 0.05\n", sep = "")
  }
}
writeLines(capture.output(sessionInfo()), file.path(cfg$out_dir, "sessionInfo_01_deseq2.txt"))
