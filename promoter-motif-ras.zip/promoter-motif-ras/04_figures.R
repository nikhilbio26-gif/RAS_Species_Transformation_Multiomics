# ==============================================================================
# File        : 04_figures.R
# Project     : promoter-motif-ras (promoter motif analysis of the RAS response, mouse vs human)
# Description : Figures: E-box / MYC-MAX / E2F motifs mouse vs human, and all-motif scatter.
# Input       : results/association/mouse_vs_human_motifs.csv
# Output      : results/figures/*.pdf
# Author      : Nikhil Gupta
# Created     : 2026-11-06
# Environment : R 4.3.3, Bioconductor 3.18 (see sessionInfo_*.txt written to results/)
# Run from    : repository root
# ==============================================================================

suppressPackageStartupMessages({
  library(dplyr); library(tidyr); library(readr); library(ggplot2); library(ggrepel); library(patchwork)
})
source("config.R"); fix_masks()

cmp <- read_csv(file.path(cfg$out_dir, "association", "mouse_vs_human_motifs.csv"), show_col_types = FALSE)
fig_dir <- file.path(cfg$out_dir, "figures")
fam_lv <- c("E-box / bHLH", "MYC / MAX", "E2F")
cols   <- c(Mouse = "#E59866", Human = "#2471A3")

# ---------------- Fig 1 ----------------
d <- cmp %>% filter(!is.na(family)) %>%
  mutate(family = factor(family, levels = fam_lv), label = make.unique(motif_name)) %>%
  arrange(family, t_mouse) %>%
  mutate(key = factor(paste(family, label, sep = "___"), levels = paste(family, label, sep = "___")))

long <- d %>%
  transmute(key, family, Mouse = t_mouse, Human = t_human,
            sig_Mouse = padj_mouse < cfg$fdr, sig_Human = padj_human < cfg$fdr) %>%
  pivot_longer(c(Mouse, Human), names_to = "species", values_to = "t") %>%
  mutate(sig = ifelse(species == "Mouse", sig_Mouse, sig_Human),
         species = factor(species, levels = c("Mouse", "Human")))

pA <- ggplot() +
  geom_vline(xintercept = 0, colour = "grey50") +
  geom_segment(data = d, aes(x = t_mouse, xend = t_human, y = key, yend = key), colour = "grey75") +
  geom_point(data = long, aes(t, key, colour = species, shape = sig), size = 2.6) +
  facet_grid(family ~ ., scales = "free_y", space = "free_y") +
  scale_y_discrete(labels = function(x) sub("^.*___", "", x)) +
  scale_colour_manual(values = cols, name = NULL) +
  scale_shape_manual(values = c(`TRUE` = 16, `FALSE` = 1), labels = c(`TRUE` = "FDR < 0.05", `FALSE` = "n.s."), name = NULL) +
  labs(x = "t statistic (positive: genes carrying the motif rise more with RAS vs control)", y = NULL, title = "Each motif") +
  theme_classic(base_size = 10) +
  theme(strip.background = element_blank(), strip.text.y = element_text(angle = 0, face = "bold"),
        axis.text.y = element_text(size = 7))

sumd <- long %>% group_by(family, species) %>% summarise(med = median(t), n = n(), .groups = "drop")
write_csv(sumd, file.path(cfg$out_dir, "association", "family_median_t.csv"))
pB <- ggplot(sumd, aes(family, med, fill = species)) +
  geom_col(position = position_dodge(0.7), width = 0.65) + geom_hline(yintercept = 0, colour = "grey40") +
  geom_text(aes(label = sprintf("%.1f", med), vjust = ifelse(med >= 0, -0.4, 1.3)),
            position = position_dodge(0.7), size = 3) +
  scale_fill_manual(values = cols, name = NULL) + scale_y_continuous(expand = expansion(mult = 0.2)) +
  labs(x = NULL, y = "Median t across the family's motifs", title = "Family summary") +
  theme_classic(base_size = 10)

fig1 <- pA + pB + plot_layout(widths = c(1.5, 1)) +
  plot_annotation(title = "Promoter motifs and the RAS response: E-box, MYC/MAX and E2F, mouse vs human",
                  subtitle = "t of motif presence vs RAS-vs-control Wald statistic across all tested genes (GC-adjusted). Filled = FDR < 0.05.",
                  tag_levels = "A")
ggsave(file.path(fig_dir, "Fig1_Ebox_MYC_E2F_mouse_vs_human.pdf"), fig1,
       width = 11, height = max(6, 0.17 * nrow(d) + 2), useDingbats = FALSE)

# ---------------- Fig 2 ----------------
rho <- cor(cmp$t_mouse, cmp$t_human, method = "spearman")
cmp$grp <- ifelse(is.na(cmp$family), "Other motifs", cmp$family)
lab <- cmp %>% filter(!is.na(family) | abs(t_mouse) > 4 | abs(t_human) > 4)
pS <- ggplot(cmp %>% arrange(grp != "Other motifs"), aes(t_mouse, t_human, colour = grp)) +
  geom_hline(yintercept = 0, colour = "grey70") + geom_vline(xintercept = 0, colour = "grey70") +
  geom_point(aes(size = grp != "Other motifs", alpha = grp != "Other motifs")) +
  geom_text_repel(data = lab, aes(label = motif_name), size = 2.6, max.overlaps = 40, show.legend = FALSE) +
  scale_colour_manual(values = c("E-box / bHLH" = "#8E44AD", "MYC / MAX" = "#2471A3", "E2F" = "#C0392B", "Other motifs" = "grey60"), name = NULL) +
  scale_size_manual(values = c(`FALSE` = 0.7, `TRUE` = 2.2), guide = "none") +
  scale_alpha_manual(values = c(`FALSE` = 0.45, `TRUE` = 1), guide = "none") +
  annotate("text", x = -Inf, y = Inf, hjust = -0.1, vjust = 1.5, label = paste0("Spearman rho = ", round(rho, 2))) +
  labs(title = "Promoter motifs vs RAS response: mouse compared with human",
       subtitle = "Each dot = one JASPAR motif; t from Wald statistic ~ motif presence + promoter GC, all tested genes per species",
       x = "Mouse promoters, mouse RAS vs control (t)", y = "Human promoters, human RAS vs control (t)") +
  theme_classic(base_size = 11)
ggsave(file.path(fig_dir, "Fig2_all_motifs_mouse_vs_human.pdf"), pS, width = 8, height = 7, useDingbats = FALSE)
cat("Figures written to", fig_dir, "\n")
