# ==============================================================================
# File        : config.R
# Project     : promoter-motif-ras (promoter motif analysis of the RAS response, mouse vs human)
# Description : Central parameters (paths, thresholds, promoter window, JASPAR settings) and helper functions.
# Input       : None (sourced by every other script)
# Output      : Creates results/ subfolders
# Author      : Nikhil Gupta
# Created     : 2026-11-06
# Environment : R 4.3.3, Bioconductor 3.18 (see sessionInfo_*.txt written to results/)
# Run from    : repository root
# ==============================================================================

cfg <- list(
  # ---- input (not tracked by git, see README) ----
  mouse_counts = "data/Mouse_RNA_CountFile.xlsx",   # col 1 = Entrez ID, other cols = raw counts
  human_counts = "data/Human_RNA_CountFile.xlsx",

  # ---- output ----
  out_dir = "results",

  # ---- DESeq2 ----
  min_count   = 10,     # gene kept if >= min_count reads ...
  min_samples = 3,      # ... in >= min_samples samples

  # ---- promoters ----
  upstream   = 1000,    # bp upstream of TSS
  downstream = 200,     # bp downstream of TSS
  max_N_frac = 0.05,    # drop promoters with > 5% N

  # ---- motifs (JASPAR2022) ----
  jaspar_collection = "CORE",
  jaspar_tax_group  = "vertebrates",
  motif_p_cutoff    = 5e-5,
  motif_bg          = "subject",   # motifmatchr background; "subject" = base composition of scanned sequences

  # ---- association model ----
  min_motif_promoters = 30,        # motif must be present in >= 30 promoters
  fdr = 0.05
)

for (d in file.path(cfg$out_dir, c("deseq2", "promoters", "association", "figures"))) {
  dir.create(d, recursive = TRUE, showWarnings = FALSE)
}

# Motif families used for grouping in the figure (grouping by motif NAME; not a JASPAR class).
# MYC/MAX also bind E-box sequences, so these groups overlap biologically.
assign_family <- function(name) {
  dplyr::case_when(
    grepl("^(E2F|TFDP)", name, ignore.case = TRUE)        ~ "E2F",
    grepl("^(MYC|MAX|MXI|MNT)", name, ignore.case = TRUE) ~ "MYC / MAX",
    grepl("^(USF|MLX|TFE3|TFEB|TFEC|MITF|BHLHE|ARNT|CLOCK|NPAS|SREBF|HEY|HES|HIF|EPAS|TCF3|TCF4|TCF12)",
          name, ignore.case = TRUE)                       ~ "E-box / bHLH",
    TRUE ~ NA_character_)
}

# Re-assert dplyr verbs: Bioconductor packages (AnnotationDbi, GenomicRanges, S4Vectors) mask them
fix_masks <- function() {
  assign("select", dplyr::select, envir = globalenv())
  assign("filter", dplyr::filter, envir = globalenv())
  assign("count",  dplyr::count,  envir = globalenv())
  assign("rename", dplyr::rename, envir = globalenv())
  assign("slice",  dplyr::slice,  envir = globalenv())
}
