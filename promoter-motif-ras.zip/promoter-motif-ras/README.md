# Promoter motif analysis of the RAS response (mouse vs human)

Tests whether JASPAR transcription-factor motifs in gene promoters are associated with the
transcriptional response to oncogenic RAS, separately in mouse and human cell lines, and compares
the two species motif by motif (E-box/bHLH, MYC/MAX and E2F families are highlighted).

## Design

- **Genes:** every gene tested by DESeq2 in that species. No fold-change or p-value cut-off, no ortholog mapping.
- **Response:** DESeq2 Wald statistic (log2 fold change / its standard error) of
  mouse RAS vs control (L), human RAS vs control (L), and human ST vs RAS (ST = small t).
  Both cell lines are pooled (`~ CellLine + Condition`). Positive = higher in the first-named condition.
- **Promoter:** -1000/+200 bp around the TSS of the longest UCSC knownGene transcript (hg38, mm39).
  Promoters with > 5% N are dropped.
- **Motifs:** JASPAR2022 CORE vertebrates (841 matrices), scanned with motifmatchr (p < 5e-5,
  background = base composition of the scanned sequences).
- **Association:** per species, contrast and motif (present in >= 30 promoters):
  `Wald statistic ~ motif presence + promoter GC`. The t of the motif term ranks motifs
  (positive = genes carrying the motif rise more). BH correction across motifs.
  Mouse and human are matched by JASPAR matrix ID; agreement is the Spearman correlation across motifs.

## Input data (not included)

Put these in `data/`:

| File | Content |
|---|---|
| `Mouse_RNA_CountFile.xlsx` | column 1 = Entrez gene ID, other columns = raw integer counts per sample |
| `Human_RNA_CountFile.xlsx` | same, human |
| `mouse_metadata.csv`, `human_metadata.csv` (optional) | columns `Sample, CellLine, Condition` (Condition: `L`, `RAS`, `ST`) |

Without the metadata CSVs, metadata is parsed from sample names in `01_deseq2.R` (`make_meta`).
Check that the printed design table shows every CellLine x Condition combination with the expected replicates.
Explicit metadata CSVs are safer.

## Run

```r
source("00_install.R")        # once
source("01_deseq2.R")         # pooled DESeq2 per species
source("02_promoters_motifs.R")   # promoters + motif scan (several minutes)
source("03_association.R")    # motif ~ response models, mouse vs human table
source("04_figures.R")
```

or `Rscript 01_deseq2.R` etc. from the repository root. All parameters are in `config.R`.

## Output (`results/`)

- `deseq2/`: results tables per contrast, sample metadata
- `promoters/`: promoter coordinates, GC, motif list, motif hit matrices (`.rds`)
- `association/`: per-contrast motif tables, `mouse_vs_human_motifs.csv`, Spearman values, family medians
- `figures/`: `Fig1_Ebox_MYC_E2F_mouse_vs_human.pdf`, `Fig2_all_motifs_mouse_vs_human.pdf`
- `sessionInfo_*.txt`: package versions

## Environment

Developed for R 4.3.3 / Bioconductor 3.18. For an exact lockfile run `renv::init()` then `renv::snapshot()`
and commit `renv.lock`. On Windows with R < 4.5, `TFBSTools` needs `TFMPvalue`, which requires Rtools
(see `00_install.R`).

## Limitations

- Motif presence is a sequence feature, not evidence of transcription factor binding or activity.
- GC adjustment is linear. GC-rich E-box, E2F and MYC motifs can still partly reflect promoter type
  (e.g. CpG-rich housekeeping promoters).
- E-box motifs of different factors (USF, MYC, MITF/TFE3, HIF) are near-identical; a signal cannot be assigned to one factor.
- Mouse and human promoters are scanned independently, but orthologous promoters share sequence,
  so agreement between species is not independent replication.
- Fold changes are not shrunk; Wald statistics are used so that noisy low-count genes carry less weight.

