# ==============================================================================
# File        : 02_promoters_motifs.R
# Project     : promoter-motif-ras (promoter motif analysis of the RAS response, mouse vs human)
# Description : Extract -1000/+200 bp promoters for all tested genes and scan JASPAR2022 CORE vertebrate motifs.
# Input       : results/deseq2/*.csv
# Output      : results/promoters/*_promoter_motif_hits.rds, motifs.csv, *_promoters.csv
# Author      : Nikhil Gupta
# Created     : 2026-11-06
# Environment : R 4.3.3, Bioconductor 3.18 (see sessionInfo_*.txt written to results/)
# Run from    : repository root
# ==============================================================================

suppressPackageStartupMessages({
  library(dplyr); library(readr)
  library(GenomicFeatures); library(GenomicRanges); library(Biostrings)
  library(TxDb.Hsapiens.UCSC.hg38.knownGene);  library(BSgenome.Hsapiens.UCSC.hg38)
  library(TxDb.Mmusculus.UCSC.mm39.knownGene); library(BSgenome.Mmusculus.UCSC.mm39)
  library(JASPAR2022); library(TFBSTools); library(motifmatchr)
})
source("config.R"); fix_masks()

# longest transcript per gene -> promoter (strand-aware): upstream/downstream of the TSS
get_promoters <- function(txdb, genome, gene_ids) {
  tx <- transcripts(txdb, columns = c("gene_id", "tx_name"))
  tx <- tx[lengths(tx$gene_id) == 1]
  tx$gene_id <- unlist(tx$gene_id)
  tx <- tx[!is.na(tx$gene_id) & tx$gene_id %in% gene_ids]
  tx <- keepStandardChromosomes(tx, pruning.mode = "coarse")
  tx <- tx[order(tx$gene_id, -width(tx))]
  tx <- tx[!duplicated(tx$gene_id)]
  prom <- trim(suppressWarnings(promoters(tx, upstream = cfg$upstream, downstream = cfg$downstream)))
  seqs <- getSeq(genome, prom)
  names(seqs) <- prom$gene_id
  list(gr = prom, seq = seqs)
}

# JASPAR2022 vertebrate CORE, one version per matrix
opts <- list(collection = cfg$jaspar_collection, tax_group = cfg$jaspar_tax_group, all_versions = FALSE)
pwms <- tryCatch(TFBSTools::getMatrixSet(JASPAR2022, opts),
                 error = function(e) {
                   db <- RSQLite::dbConnect(RSQLite::SQLite(), JASPAR2022@db)
                   TFBSTools::getMatrixSet(db, opts)
                 })
motifs <- data.frame(motif_id = vapply(pwms, TFBSTools::ID, ""),
                     motif_name = vapply(pwms, TFBSTools::name, ""), stringsAsFactors = FALSE)
cat("Motifs:", nrow(motifs), "\n")
write_csv(motifs, file.path(cfg$out_dir, "promoters", "motifs.csv"))

species <- list(
  mouse = list(txdb = TxDb.Mmusculus.UCSC.mm39.knownGene, genome = BSgenome.Mmusculus.UCSC.mm39,
               de = "mouse_RAS_vs_L.csv"),
  human = list(txdb = TxDb.Hsapiens.UCSC.hg38.knownGene,  genome = BSgenome.Hsapiens.UCSC.hg38,
               de = "human_RAS_vs_L.csv"))

for (sp in names(species)) {
  S  <- species[[sp]]
  de <- read_csv(file.path(cfg$out_dir, "deseq2", S$de), col_types = cols(GeneID = col_character()))
  ids <- de$GeneID                                   # all tested genes
  P   <- get_promoters(S$txdb, S$genome, ids)
  keep <- names(P$seq)[letterFrequency(P$seq, "N", as.prob = TRUE)[, 1] <= cfg$max_N_frac]
  seqs <- P$seq[keep]
  cat(sp, ": tested genes", length(ids), "| with promoter", length(P$seq), "| after N filter", length(keep), "\n")

  gc <- letterFrequency(seqs, "GC", as.prob = TRUE)[, 1]; names(gc) <- names(seqs)
  m  <- motifmatchr::matchMotifs(pwms, seqs, out = "matches",
                                 p.cutoff = cfg$motif_p_cutoff, bg = cfg$motif_bg)
  hits <- as.matrix(motifmatchr::motifMatches(m))
  rownames(hits) <- names(seqs); colnames(hits) <- motifs$motif_id
  stopifnot(nrow(hits) == length(gc), ncol(hits) == nrow(motifs))

  saveRDS(list(hits = hits, gc = gc), file.path(cfg$out_dir, "promoters", paste0(sp, "_promoter_motif_hits.rds")))
  pr <- as.data.frame(P$gr[P$gr$gene_id %in% keep])[, c("gene_id", "seqnames", "start", "end", "strand")]
  pr$GC <- gc[pr$gene_id]
  write_csv(pr, file.path(cfg$out_dir, "promoters", paste0(sp, "_promoters.csv")))
  cat(sp, "mean motif hits per promoter:", round(mean(rowSums(hits)), 1), "\n")
}
writeLines(capture.output(sessionInfo()), file.path(cfg$out_dir, "sessionInfo_02_motifs.txt"))
