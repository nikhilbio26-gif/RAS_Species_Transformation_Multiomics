# ==============================================================================
# File        : 00_install.R
# Project     : promoter-motif-ras (promoter motif analysis of the RAS response, mouse vs human)
# Description : Install all CRAN and Bioconductor dependencies (run once).
# Input       : None
# Output      : Installed packages
# Author      : Nikhil Gupta
# Created     : 2026-11-06
# Environment : R 4.3.3, Bioconductor 3.18 (see sessionInfo_*.txt written to results/)
# Run from    : repository root
# ==============================================================================

cran <- c("readxl", "dplyr", "tidyr", "readr", "ggplot2", "ggrepel", "patchwork", "BiocManager")
for (p in cran) if (!requireNamespace(p, quietly = TRUE)) install.packages(p)

bioc <- c("DESeq2", "AnnotationDbi", "org.Mm.eg.db", "org.Hs.eg.db",
          "GenomicFeatures", "GenomicRanges", "Biostrings", "BSgenome",
          "TxDb.Hsapiens.UCSC.hg38.knownGene", "BSgenome.Hsapiens.UCSC.hg38",
          "TxDb.Mmusculus.UCSC.mm39.knownGene", "BSgenome.Mmusculus.UCSC.mm39",
          "JASPAR2022", "TFBSTools", "motifmatchr", "RSQLite")
for (p in bioc) if (!requireNamespace(p, quietly = TRUE)) {
  BiocManager::install(p, ask = FALSE, update = FALSE)
}

# Windows + R < 4.5: TFBSTools needs TFMPvalue, which must be compiled.
# Install Rtools matching your R (Rtools43 for R 4.3.x), restart R, then:
#   install.packages("https://cran.r-project.org/src/contrib/Archive/TFMPvalue/TFMPvalue_0.0.9.tar.gz",
#                    repos = NULL, type = "source")
#   BiocManager::install("TFBSTools")

missing <- setdiff(c(cran, bioc), rownames(installed.packages()))
if (length(missing)) stop("Not installed: ", paste(missing, collapse = ", ")) else cat("All packages installed.\n")
