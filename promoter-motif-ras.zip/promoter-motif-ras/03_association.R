# ==============================================================================
# File        : 03_association.R
# Project     : promoter-motif-ras (promoter motif analysis of the RAS response, mouse vs human)
# Description : Per-motif GC-adjusted association with the RAS/ST response (Wald statistic ~ motif + GC); mouse vs human comparison.
# Input       : results/deseq2/*.csv, results/promoters/*
# Output      : results/association/*.csv, spearman_mouse_vs_human.txt
# Author      : Nikhil Gupta
# Created     : 2026-11-06
# Environment : R 4.3.3, Bioconductor 3.18 (see sessionInfo_*.txt written to results/)
# Run from    : repository root
# ==============================================================================

suppressPackageStartupMessages({ library(dplyr); library(readr) })
source("config.R"); fix_masks()

motifs <- read_csv(file.path(cfg$out_dir, "promoters", "motifs.csv"), show_col_types = FALSE)

run_assoc <- function(de, P, label) {
  s <- setNames(de$stat, de$GeneID); s <- s[!is.na(s)]
  g <- intersect(names(s), rownames(P$hits))
  y <- as.numeric(s[g]); gc <- as.numeric(P$gc[g]); H <- P$hits[g, , drop = FALSE]
  cat(label, ": genes used =", length(g), "\n")
  res <- lapply(seq_len(ncol(H)), function(j) {
    h <- as.numeric(H[, j]); n <- sum(h)
    if (n < cfg$min_motif_promoters || n == length(h)) return(NULL)
    cf <- summary(lm(y ~ h + gc))$coefficients["h", ]
    data.frame(motif_id = colnames(H)[j], n_with_motif = n, n_genes = length(g),
               effect = unname(cf[1]), t = unname(cf[3]), p = unname(cf[4]))
  })
  out <- bind_rows(res) %>%
    left_join(motifs, by = "motif_id") %>%
    mutate(padj = p.adjust(p, "BH"), contrast = label,
           family = assign_family(motif_name)) %>%
    arrange(desc(t)) %>%
    mutate(rank = row_number(), total = n(), pctile = round(100 * rank / total, 1))
  out
}

jobs <- list(
  list(sp = "mouse", de = "mouse_RAS_vs_L.csv",  label = "mouse_RAS_vs_L"),
  list(sp = "human", de = "human_RAS_vs_L.csv",  label = "human_RAS_vs_L"),
  list(sp = "human", de = "human_ST_vs_RAS.csv", label = "human_ST_vs_RAS"))

res_list <- list()
for (j in jobs) {
  P  <- readRDS(file.path(cfg$out_dir, "promoters", paste0(j$sp, "_promoter_motif_hits.rds")))
  de <- read_csv(file.path(cfg$out_dir, "deseq2", j$de), col_types = cols(GeneID = col_character()))
  r  <- run_assoc(de, P, j$label)
  write_csv(r, file.path(cfg$out_dir, "association", paste0("motif_association_", j$label, ".csv")))
  res_list[[j$label]] <- r
}

# mouse vs human, matched by JASPAR matrix ID
pick <- function(r, suffix) r %>% select(motif_id, motif_name, family,
                                         !!paste0("t_", suffix) := t, !!paste0("padj_", suffix) := padj,
                                         !!paste0("rank_", suffix) := rank)
cmp <- pick(res_list$mouse_RAS_vs_L, "mouse") %>%
  inner_join(select(pick(res_list$human_RAS_vs_L, "human"), -motif_name, -family), by = "motif_id") %>%
  inner_join(select(pick(res_list$human_ST_vs_RAS, "human_ST"), motif_id, t_human_ST, padj_human_ST), by = "motif_id")
write_csv(cmp, file.path(cfg$out_dir, "association", "mouse_vs_human_motifs.csv"))

rho <- c(mouse_RAS_vs_human_RAS = cor(cmp$t_mouse, cmp$t_human,    method = "spearman"),
         mouse_RAS_vs_human_ST  = cor(cmp$t_mouse, cmp$t_human_ST, method = "spearman"))
cat("\nSpearman correlation of motif t statistics across", nrow(cmp), "motifs\n"); print(round(rho, 3))
writeLines(c(paste("n_motifs:", nrow(cmp)), paste(names(rho), round(rho, 4))),
           file.path(cfg$out_dir, "association", "spearman_mouse_vs_human.txt"))

cat("\nE2F and MYC/MAX motifs (mouse vs human):\n")
print(as.data.frame(cmp %>% filter(family %in% c("E2F", "MYC / MAX")) %>%
        arrange(rank_mouse) %>% select(motif_name, rank_mouse, t_mouse, rank_human, t_human, padj_human) %>%
        mutate(across(where(is.numeric), ~ round(.x, 3)))), row.names = FALSE)
writeLines(capture.output(sessionInfo()), file.path(cfg$out_dir, "sessionInfo_03_association.txt"))
